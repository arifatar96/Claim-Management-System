import React, { useState } from 'react';
import SendIcon from '@mui/icons-material/Send';
import axios from 'axios';

import {
  Container,
  Typography,
  TextField,
  Button,
  Paper,
  List,
  ListItem,
  ListItemText,
  Divider,
} from '@mui/material';

const AdminQueryPage = () => {
  const [message, setMessage] = useState('');
  const [sentMessage, setSentMessage] = useState('');

  const handleSendMessage = () => {
    const data = {
      actors: "client@gmail.comTOadmin@gmail.com",
      message: message,
    };

    axios.post('http://localhost:9092/message/sendMessage', data)
      .then((response) => {
        console.log(response.data); // The updated message content
        setSentMessage(response.data);
      })
      .catch((error) => {
        console.error('Error sending message:', error);
      });
  };

  return (
    <Container component="main" maxWidth="md">
      <Typography component="h1" variant="h5" mt={6} mb={3} align="center">
        Send Message
      </Typography>

      <Paper elevation={3} sx={{ padding: '16px' }}>
        <TextField
          fullWidth
          label="Message"
          variant="outlined"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          multiline
          rows={4}
          sx={{ marginBottom: '16px' }}
        />
        <Button
          variant="contained"
          endIcon={<SendIcon />}
          color="primary"
          onClick={handleSendMessage}
        >
          Send
        </Button>
      </Paper>

      {sentMessage && (
        <Paper elevation={3} sx={{ marginTop: '16px', padding: '16px' }}>
          <Typography component="h2" variant="h6" sx={{ marginBottom: '8px' }}>
            Sent Message
          </Typography>
          <List>
            <ListItem>
              <ListItemText primary={sentMessage} />
            </ListItem>
          </List>
        </Paper>
      )}
    </Container>
  );
};

export default AdminQueryPage;





// import React, { useState } from 'react';
// import SendIcon from '@mui/icons-material/Send';
// import axios from 'axios';

// import {
//   Container,
//   Typography,
//   TextField,
//   Button,
//   Paper,
//   List,
//   ListItem,
//   ListItemText,
//   Divider,
// } from '@mui/material';

// const AdminQueryPage = () => {
//   const [message, setMessage] = useState('');
//   const [sentMessage, setSentMessage] = useState('');

//   const handleSendMessage = () => {
//     const data = {
//       actors: "client@gmail.comTOadmin@gmail.com",
//       message: message,
//     };

//     axios.post('http://localhost:9092/message/sendMessage', data)
//       .then((response) => {
//         console.log(response.data); // The updated message content
//         setSentMessage(response.data);
//       })
//       .catch((error) => {
//         console.error('Error sending message:', error);
//       });
//   };

//   return (
//     <Container component="main" maxWidth="md">
//       <Typography component="h1" variant="h5" mt={6} mb={3} align="center">
//         Send Message
//       </Typography>

//       <Paper elevation={3} sx={{ padding: '16px' }}>
//         <TextField
//           fullWidth
//           label="Message"
//           variant="outlined"
//           value={message}
//           onChange={(e) => setMessage(e.target.value)}
//           multiline
//           rows={4}
//           sx={{ marginBottom: '16px' }}
//         />
//         <Button
//           variant="contained"
//           endIcon={<SendIcon />}
//           color="primary"
//           onClick={handleSendMessage}
//         >
//           Send
//         </Button>
//       </Paper>

//       {sentMessage && (
//         <Paper elevation={3} sx={{ marginTop: '16px', padding: '16px' }}>
//           <Typography component="h2" variant="h6" sx={{ marginBottom: '8px' }}>
//             Sent Message
//           </Typography>
//           <List>
//             <ListItem>
//               <ListItemText primary={sentMessage} />
//             </ListItem>
//           </List>
//         </Paper>
//       )}
//     </Container>
//   );
// };

// export default AdminQueryPage;

// import React, { useState, useEffect } from 'react';
// import SendIcon from '@mui/icons-material/Send';
// import axios from 'axios';

// import {
//   Container,
//   Typography,
//   Paper,
//   List,
//   ListItem,
//   ListItemText,
//   Divider,
//   TextField,
//   Button,
// } from '@mui/material';

// const AdminQueryPage = () => {
//   const [clientQueries, setClientQueries] = useState([]);

//   useEffect(() => {
//     // Fetch client queries from the server

//     const data = {
//       actors: "client@gmail.comTOadmin@gmail.com"
//     };

//     axios.post('http://localhost:9092/message/receiveMessage', data)
//       .then((response) => {
//         const messageMap = response.data;

//         const queries = Object.keys(messageMap).map((dateKey) => {
//           const dateMessageMap = messageMap[dateKey];
//           const formattedDate = new Date(dateKey).toLocaleDateString();

//           return Object.keys(dateMessageMap).map((timeKey) => {
//             const messageContent = dateMessageMap[timeKey];
//             return {
//               id: `${dateKey}_${timeKey}`,
//               date: formattedDate,
//               time: timeKey,
//               message: messageContent,
//               reply: '',
//             };
//           });
//         }).flat();

//         setClientQueries(queries);
//       })
//       .catch((error) => {
//         console.error('Error fetching client queries:', error);
//       });
//   }, []);

//   // Function to handle admin reply to client query
//   const handleReply = (id, reply) => {
//     const updatedClientQueries = clientQueries.map((query) =>
//       query.id === id ? { ...query, reply } : query
//     );
//     setClientQueries(updatedClientQueries);
//   };

//   return (
//     <Container component="main" maxWidth="md">
//       <Typography component="h1" variant="h5" mt={6} mb={3} align="center">
//         Client Queries
//       </Typography>

//       <Paper elevation={3}>
//         <List>
//           {clientQueries.map((query) => (
//             <React.Fragment key={query.id}>
//               <ListItem>
//                 <ListItemText
//                   primary={query.date}
//                   secondary={
//                     <>
//                       {query.time}
//                       <br />
//                       {query.message}
//                     </>
//                   }
//                 />
//               </ListItem>
//               <Divider component="li" />
//               <ListItem>
//                 <TextField
//                   fullWidth
//                   label="Admin Reply"
//                   variant="outlined"
//                   value={query.reply}
//                   onChange={(e) => handleReply(query.id, e.target.value)}
//                 />
//                 <Button
//                   variant="outlined"
//                   endIcon={<SendIcon />}
//                   color="primary"
//                   onClick={() => handleReply(query.id, query.reply)}
//                   style={{ marginLeft: '8px' }}
//                 >
//                   Send
//                 </Button>
//               </ListItem>
//             </React.Fragment>
//           ))}
//         </List>
//       </Paper>
//     </Container>
//   );
// };

// export default AdminQueryPage;



// import React, { useState, useEffect } from 'react';
// import SendIcon from '@mui/icons-material/Send';
// import axios from 'axios';

// import {
//   Container,
//   Typography,
//   Paper,
//   List,
//   ListItem,
//   ListItemText,
//   Divider,
//   TextField,
//   Button,
// } from '@mui/material';

// const AdminQueryPage = () => {
//   const [clientQueries, setClientQueries] = useState([]);

//   useEffect(() => {
//     // Fetch client queries from the server

//     const data = {
//       actors: "client@gmail.comTOadmin@gmail.com"
//     }
//     try {
//       const response = axios({
//         method: "POST",
//         url: "http://localhost:9092/message/receiveMessage",
//         headers: { "content-type": "application/json" },
//         data: data,
//       });

//       if (response) {

//       console.log(response);
//         console.log(response.data);
//       }

//     } catch (error) {
//       console.log(error);
//     }


//     // axios.post('http://localhost:9092/message/receiveMessage',
//     // {
//     //   actors: "client@gmail.comTOadmin@gmail.com"
//     // })
//     //   .then((response) => {
//     //     console.log(response);
//     //     console.log(response.data);
//     //     // setClientQueries(response.data);
//     //   })
//     //   .catch((error) => {
//     //     console.error('Error fetching client queries:', error);
//     //   });
//   }, []);

//   // Function to handle admin reply to client query
//   const handleReply = (id, reply) => {
//     const updatedClientQueries = clientQueries.map((query) =>
//       query.id === id ? { ...query, reply } : query
//     );
//     setClientQueries(updatedClientQueries);
//   };

//   return (
//     <Container component="main" maxWidth="md">
//       <Typography component="h1" variant="h5" mt={6} mb={3} align="center">
//         Client Queries
//       </Typography>

//       <Paper elevation={3}>
//         <List>
//           {clientQueries.map((query) => (
//             <React.Fragment key={query.id}>
//               <ListItem>
//                 <ListItemText
//                   primary={query.name}
//                   secondary={
//                     <>
//                       <Typography component="span" variant="body2" color="text.primary">
//                         {query.email}
//                       </Typography>
//                       <br />
//                       {query.query}
//                       <br />
//                       <Typography component="span" variant="body2" color="text.secondary">
//                         {query.date}
//                       </Typography>
//                     </>
//                   }
//                 />
//               </ListItem>
//               <Divider component="li" />
//               <ListItem>
//                 <TextField
//                   fullWidth
//                   label="Admin Reply"
//                   variant="outlined"
//                   value={query.reply}
//                   onChange={(e) => handleReply(query.id, e.target.value)}
//                 />
//                 <Button
//                   variant="outlined"
//                   endIcon={<SendIcon />}
//                   color="primary"
//                   onClick={() => handleReply(query.id, query.reply)}
//                   style={{ marginLeft: '8px' }}
//                 >
//                   Send
//                 </Button>
//               </ListItem>
//             </React.Fragment>
//           ))}
//         </List>
//       </Paper>
//     </Container>
//   );
// };

// export default AdminQueryPage;










// // import React, { useState } from 'react';
// // import SendIcon from '@mui/icons-material/Send';

// // import {
// //   Container,
// //   Typography,
// //   Paper,
// //   List,
// //   ListItem,
// //   ListItemText,
// //   Divider,
// //   TextField,
// //   Button,
// // } from '@mui/material';

// // const AdminQueryPage = () => {
// //   // Sample data for client queries
// //   const initialClientQueries = [
// //     {
// //       id: 1,
// //       name: 'Arif Atar',
// //       email: 'arifatar@example.com',
// //       query: 'I have a question about my insurance claim status.',
// //       date: '2023-08-02',
// //       reply: '',
// //     },
// //     {
// //       id: 2,
// //       name: 'Akash Sharma',
// //       email: 'akash@example.com',
// //       query: 'How can I update my contact information?',
// //       date: '2023-08-01',
// //       reply: '',
// //     },
// //   ];

// //   const [clientQueries, setClientQueries] = useState(initialClientQueries);

// //   // Function to handle admin reply to client query
// //   const handleReply = (id, reply) => {
// //     const updatedClientQueries = clientQueries.map((query) =>
// //       query.id === id ? { ...query, reply } : query
// //     );
// //     setClientQueries(updatedClientQueries);
// //   };

// //   return (
// //     <Container component="main" maxWidth="md">
// //       <Typography component="h1" variant="h5" mt={6} mb={3} align="center">
// //         Client Queries
// //       </Typography>

// //       <Paper elevation={3}>
// //         <List>
// //           {clientQueries.map((query) => (
// //             <React.Fragment key={query.id}>
// //               <ListItem>
// //                 <ListItemText
// //                   primary={query.name}
// //                   secondary={
// //                     <>
// //                       <Typography component="span" variant="body2" color="text.primary">
// //                         {query.email}
// //                       </Typography>
// //                       <br />
// //                       {query.query}
// //                       <br />
// //                       <Typography component="span" variant="body2" color="text.secondary">
// //                         {query.date}
// //                       </Typography>
// //                     </>
// //                   }
// //                 />
// //               </ListItem>
// //               <Divider component="li" />
// //               <ListItem>
// //                 <TextField
// //                   fullWidth
// //                   label="Admin Reply"
// //                   variant="outlined"
// //                   value={query.reply}
// //                   onChange={(e) => handleReply(query.id, e.target.value)}
// //                 />
// //                 <Button
// //                   variant="outlined"
// //                   endIcon={<SendIcon />}
// //                   color="primary"
// //                   onClick={() => handleReply(query.id, query.reply)}
// //                   style={{ marginLeft: '8px' }}
// //                 >
// //                   Send
// //                 </Button>
// //               </ListItem>
// //             </React.Fragment>
// //           ))}
// //         </List>
// //       </Paper>
// //     </Container>
// //   );
// // };

// // export default AdminQueryPage;
