import React, { useEffect, useMemo, useState } from "react";
import {
  Table,
  Typography,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Grid,
  Box,
} from "@mui/material";
import { MaterialReactTable } from "material-react-table";
import axios from "axios";

const claimSettlementDetails = () => {
  return axios
    .get("http://localhost:9093/allSettlementClaims")
    .then((response) => response.data);
};

export default function RomeChangeRequests() {
  const [settlmentClaims, setSettlementClaims] = useState([]);

  useEffect(() => {
    claimSettlementDetails()
      .then((resp) => {
        console.log(resp);
        const formattedClaims = resp.map((claim) => ({
          ...claim,
          settlementDate: claim.settlementDate.split("T")[0], // Format date here
        }));
        setSettlementClaims(formattedClaims);
        // setSettlementClaims(resp);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const columns = useMemo(
    () => [
      {
        accessorKey: "schemeName",
        header: "SCHEME NAME",
      },
      {
        accessorKey: "email",
        header: "CLIENT EMAIL",
      },
      {
        accessorKey: "clientName",
        header: "CLIENT NAME",
      },
      {
        accessorKey: "premiumAmount",
        header: "PREMIUM AMOUNT",
      },
      {
        accessorKey: "claimPercentage",
        header: "CLAIM PERCENTAGE",
      },
      {
        accessorKey: "settlementAmount",
        header: "AMOUNT",
      },
      {
        accessorKey: "settlementDate",
        header: "SETTLEMENT DATE",
        // customRender: ({ value }) => value.split("T")[0],
      },
    ],
    []
  );

  return (
    <React.Fragment>
      <Box
        sx={{
          marginTop: 6,
          alignItems: "center",
          boxShadow: 7,
          p: 3,
        }}
      >
        <Typography component="h2" variant="h5" mb={3} align="center">
          Claim Settlement Records
        </Typography>
        <Grid item xs={12}>
          <div style={{ height: 300, width: "100%", border: "solid 1px " }}>
            <MaterialReactTable columns={columns} data={settlmentClaims} />
          </div>
        </Grid>
      </Box>
    </React.Fragment>
  );
}








// import React, { useMemo, useState } from "react";
// import {
//   Table,
//   Typography,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   Grid,
//   Box,
// } from "@mui/material";
// import { MaterialReactTable } from "material-react-table";

// const claimSettlementDetails = () => {
//   return axios
//     .get("http://localhost:9093/allClaims")
//     .then((response) => response.data);
// };

// export default function RomeChangeRequests() {
//   const [settlmentClaims, setSettlementClaims] = useState([]);

//   const columns = useMemo(
//     () => [
//       {
//         accessorKey: "id",
//         header: "ID",
//       },

//       {
//         accessorKey: "claimId",
//         header: "CLAIM ID",
//       },

//       {
//         accessorKey: "amount",
//         header: "AMOUNT",
//       },

//       {
//         accessorKey: "transactionDate",
//         header: "TRANSACTION DATE",
//       },

//       {
//         accessorKey: "status",
//         header: "STATUS",
//       },
//     ],
//     [] //end
//   );

//   const [rows, setRows] = useState([
//     {
//       id: 1,
//       claimId: 12345,
//       amount: 1000,
//       transactionDate: "2023-07-25",
//       status: "pending",
//     },
//     {
//       id: 2,
//       claimId: 67890,
//       amount: 500,
//       transactionDate: "2023-07-26",
//       status: "success",
//     },
//   ]);

//   useEffect(() => {
//     claimSettlementDetails()
//       .then((resp) => {
//         console.log(resp);
//         setSettlementClaims(resp)
//       })
//       .catch((error) => {
//         console.log(error);
//       });
//   }, []);

//   const claimId = 67890;
//   // sessionStorage.getItem('currentpatientid');

//   const sortedRows = rows.filter((row) => row.claimId === claimId);

//   return (
//     <React.Fragment>
//       <Box
//         sx={{
//           marginTop: 6,
//           alignItems: "center",
//           boxShadow: 7,
//           p: 3,
//         }}
//       >
//         <Typography component="h2" variant="h5" mb={3} align="center">
//           Claim Settlement Records
//         </Typography>
//         <Grid item xs={12}>
//           <div style={{ height: 300, width: "100%", border: "solid 1px " }}>
//             <MaterialReactTable columns={columns} data={rows} />
//           </div>
//         </Grid>
//       </Box>
//     </React.Fragment>
//   );
// }
