import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Button,
  Box,
  Container,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Paper,
  Snackbar,
  Alert,
} from "@mui/material";

const claimDetails = () => {
  return axios
    .get(`http://localhost:9093/allClaims`)
    .then((response) => response.data);
};

const ClaimTracking = () => {
  const [claims, setClaims] = useState([]);
  const email = sessionStorage.getItem("email");

  useEffect(() => {
    claimDetails()
      .then((resp) => {
        const allClaims = resp.filter((claim) => claim.email === email);
        setClaims(allClaims);
        console.log(allClaims);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  return (
    <Container component="main" maxWidth="md">
      <Box
        boxShadow={"5px 5px 10px grey"}
        sx={{
          margin: 8,
          pb: 3,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Typography component="h2" variant="h5" mt={3} mb={3} align="center">
          Claim Tracking
        </Typography>

        <Table>
          <TableHead>
            <TableRow>
              <TableCell sx={{ fontWeight: "bold" }}>Scheme Name</TableCell>
              <TableCell sx={{ fontWeight: "bold" }}>Premium Amount</TableCell>
              <TableCell sx={{ fontWeight: "bold" }}>Applied Date</TableCell>
              <TableCell sx={{ fontWeight: "bold" }}>
                Claim Percentage
              </TableCell>
              <TableCell sx={{ fontWeight: "bold" }}>Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {claims.map((claim) => (
              <TableRow key={claim.id}>
                <TableCell>{claim.schemeName}</TableCell>
                <TableCell>₹ {claim.premiumAmount}</TableCell>
                <TableCell>{claim.claimDate.split("T")[0]}</TableCell>
                <TableCell>{claim.claimPercentage}%</TableCell>
                <TableCell>{claim.claimSettle === "Success" ? "Approved" : "Pending"}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Box>
    </Container>
  );
};

export default ClaimTracking;
