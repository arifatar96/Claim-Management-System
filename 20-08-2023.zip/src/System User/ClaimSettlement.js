import React, { useState } from "react";
import {
  TextField,
  Button,
  Box,
  Stack,
  Grid,
  Container,
  Typography,
  Snackbar,
  Alert,
} from "@mui/material";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";
import axios from "axios";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";

const ClaimSettlement = ({ existingClaim }) => {
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [alertMessage, setAlertMessage] = useState("");

  const premiumAmount = existingClaim.premiumAmount;
  const claimPercentage = existingClaim.claimPercentage;

  const settlementAmount = (premiumAmount * claimPercentage) / 100;

  // Handler for form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    const currentDate = new Date().toISOString().split("T")[0];

    const settlement = {
      email: existingClaim.email,
      clientName: existingClaim.clientName,
      schemeName: existingClaim.schemeName,
      premiumAmount: existingClaim.premiumAmount,
      claimPercentage: existingClaim.claimPercentage,
      settlementDate: currentDate,
      settlementAmount: settlementAmount,
    };

      const data = {
      ...existingClaim,
      claimSettle: "Success"
    };

    settlementDetails(settlement)
      .then((resp) => {
        setAlertMessage(
          `${existingClaim.clientName} Claim Settled Successfully`
        );
        setOpenSnackbar(true);
        console.log(resp);
      })
      .catch((error) => {
        console.log(error);
      });

      updateClaim(data)
      .then((resp) => {
        window.location.reload();
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const updateClaim = (data) => {
    return axios
      .put("http://localhost:9093/updateClaim", data, {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      })
      .then((response) => response.data);
  };


  const settlementDetails = (settlement) => {
    return axios
      .post("http://localhost:9093/addSettlementClaim", settlement, {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      })
      .then((response) => response.data);
  };

  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };

  return (
    <Container component="main" maxWidth="sm">
      <Box
        boxShadow={"5px 5px 10px grey"}
        sx={{
          margin: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Typography component="h1" variant="h5" mt={3}>
          Claim Settlement
        </Typography>

        {/* <p>
          <strong>Scheme Name:</strong> {existingClaim.schemeName},{" "}
          <strong>Claim Date:</strong> {existingClaim.claimDate.split("T")[0]}
        </p>
        <p>
          <strong>Client Name:</strong> {existingClaim.clientName},{" "}
          <strong>Claim Amount:</strong> {settlementAmount}
        </p> */}

        {/* <p>
          <strong>Claim Percentage:</strong> {existingClaim.claimPercentage}%,{" "}
          <strong>Supporting Document:</strong> {existingClaim.supportngDocs}
        </p>
        <p>
          <strong>Approved By:</strong> {existingClaim.adminEmail},{" "}
          <strong>Admin Comment:</strong> {existingClaim.adminUpdate}
        </p> */}

        <Box component="form" sx={{ m: 2 }}>
          <List disablePadding>
            <ListItem
              key={existingClaim.name}
              sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
            >
              <Typography
                variant="body1"
                sx={{ fontWeight: "bold", width: 150 }}
              >
                Scheme Name:
              </Typography>
              <Typography variant="body1">
                {existingClaim.schemeName}
              </Typography>
            </ListItem>
            <ListItem
              key={existingClaim.claimDate}
              sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
            >
              <Typography
                variant="body1"
                sx={{ fontWeight: "bold", width: 150 }}
              >
                Claim Date:
              </Typography>
              <Typography variant="body1">
                {existingClaim.claimDate.split("T")[0]}
              </Typography>
            </ListItem>
            <ListItem
              key={existingClaim.clientName}
              sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
            >
              <Typography
                variant="body1"
                sx={{ fontWeight: "bold", width: 150 }}
              >
                Client Name:
              </Typography>
              <Typography variant="body1">
                {existingClaim.clientName}
              </Typography>
            </ListItem>
            <ListItem
              key={existingClaim.settlementAmount}
              sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
            >
              <Typography
                variant="body1"
                sx={{ fontWeight: "bold", width: 150 }}
              >
                Claim Amount:
              </Typography>
              <Typography variant="body1">{settlementAmount}</Typography>
            </ListItem>

            <ListItem
              key={existingClaim.adminEmail}
              sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
            >
              <Typography
                variant="body1"
                sx={{ fontWeight: "bold", width: 150 }}
              >
                Approved By:
              </Typography>
              <Typography variant="body1">{existingClaim.adminEmail}</Typography>
            </ListItem>

            <ListItem
              key={existingClaim.adminUpdate}
              sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
            >
              <Typography
                variant="body1"
                sx={{ fontWeight: "bold", width: 150 }}
              >
                Admin Update:
              </Typography>
              <Typography variant="body1">{existingClaim.adminUpdate}</Typography>
            </ListItem>
          </List>

          <Button
            sx={{ mt: 2, ml: 6 }}
            type="submit"
            variant="outlined"
            color="primary"
            onClick={handleSubmit}
            endIcon={<ArrowForwardIcon />}
          >
            Process
          </Button>
        </Box>
      </Box>

      <Snackbar
        open={openSnackbar}
        autoHideDuration={3000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
      >
        <Alert onClose={handleCloseSnackbar} severity="success">
          {alertMessage}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default ClaimSettlement;
