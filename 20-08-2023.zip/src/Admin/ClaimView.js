import React from "react";
import {
  TextField,
  Button,
  Box,
  Stack,
  Grid,
  Container,
  Typography,
} from "@mui/material";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import VerifiedUserOutlinedIcon from "@mui/icons-material/VerifiedUserOutlined";
import ThumbDownAltOutlinedIcon from "@mui/icons-material/ThumbDownAltOutlined";
import axios from "axios";

const ClaimView = ({
  existingClaim,
  handleApproveClaim,
  handleRejectClaim,
}) => {
  // State to hold the form input values
  const [updateDescription, setUpdateDescription] = React.useState("");

  const handleDownload = (id) => {
    console.log(id);
    axios
      .get(`http://localhost:9093/get/${id}`, { responseType: "blob" })
      .then((response) => {
        // Create a blob from the response data
        const blob = new Blob([response.data], {
          type: response.headers["content-type"],
        });

        // Create a URL for the blob
        const url = window.URL.createObjectURL(blob);

        // Create a temporary anchor element to trigger the download
        const a = document.createElement("a");
        a.href = url;
        a.download = existingClaim.fileName; // Set desired filename
        document.body.appendChild(a);
        a.click();

        // Clean up
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      })
      .catch((error) => {
        console.error(error);
        // Display error message or perform error handling
      });
  };

  return (
    <Container component="main" maxWidth="md">
      <Box
        boxShadow={"5px 5px 10px grey"}
        sx={{
          margin: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Typography component="h2" variant="h5" mt={3}>
          Claim Details
        </Typography>

        <List disablePadding>
          <ListItem
            sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
          >
            <Typography variant="h6" sx={{ fontWeight: "bold", width: 180 }}>
              Scheme Name:
            </Typography>
            <Typography variant="h6">{existingClaim.schemeName}</Typography>
          </ListItem>
          <ListItem
            sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
          >
            <Typography variant="body1" sx={{ fontWeight: "bold", width: 180 }}>
              Claim Date :
            </Typography>
            <Typography variant="body1">
              {existingClaim.claimDate.split("T")[0]}
            </Typography>
          </ListItem>
          <ListItem
            sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
          >
            <Typography variant="body2" sx={{ fontWeight: "bold", width: 180 }}>
              Client Name :
            </Typography>
            <Typography variant="body2">{existingClaim.clientName}</Typography>
          </ListItem>
          <ListItem
            sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
          >
            <Typography variant="body2" sx={{ fontWeight: "bold", width: 180 }}>
              Client Email :
            </Typography>
            <Typography variant="body2">{existingClaim.email}</Typography>
          </ListItem>
          <ListItem
            sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
          >
            <Typography variant="body2" sx={{ fontWeight: "bold", width: 180 }}>
              Reason :
            </Typography>
            <Typography variant="body2">{existingClaim.reason}</Typography>
          </ListItem>

          <ListItem
            sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
          >
            <Typography variant="body2" sx={{ fontWeight: "bold", width: 180 }}>
              Claim Percentage :
            </Typography>
            <Typography variant="body2">
              {existingClaim.claimPercentage}%
            </Typography>
          </ListItem>

          <ListItem
            sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
          >
            <Typography variant="body2" sx={{ fontWeight: "bold", width: 180 }}>
              Supporting Document :
            </Typography>

            <button onClick={() => handleDownload(existingClaim.id)}>
              Download
            </button>
          </ListItem>

        <ListItem
            sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
          >
            <Typography variant="body2" sx={{ fontWeight: "bold", width: 180 }}>
              Approved By :
            </Typography>
            <Typography variant="body2">{existingClaim.userEmail}</Typography>
          </ListItem>

          <ListItem
            sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
          >
            <Typography variant="body2" sx={{ fontWeight: "bold", width: 180 }}>
              User Comment :
            </Typography>
            <Typography variant="body2">{existingClaim.userUpdate}</Typography>
          </ListItem>
        </List>

        <Box component="form" sx={{ m: 3 }}>
          <Grid container spacing={2}>
            <TextField
              autoFocus
              label="Update Description"
              value={updateDescription}
              onChange={(e) => setUpdateDescription(e.target.value)}
              required
              fullWidth
              multiline
              rows={3}
            />
          </Grid>

          <Stack
            spacing={3}
            direction="row"
            justifyContent="center"
            alignItems="center"
            sx={{ mt: 2, mb: 2 }}
          >
            <Button
              variant="outlined"
              startIcon={<VerifiedUserOutlinedIcon />}
              color="primary"
              onClick={() =>
                handleApproveClaim(existingClaim, updateDescription)
              }
            >
              Approve
            </Button>

            <Button
              variant="outlined"
              startIcon={<ThumbDownAltOutlinedIcon />}
              color="error"
              onClick={() =>
                handleRejectClaim(existingClaim, updateDescription)
              }
            >
              Reject
            </Button>
          </Stack>
        </Box>
      </Box>
    </Container>
  );
};

export default ClaimView;
