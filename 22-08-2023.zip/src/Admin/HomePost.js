import * as React from "react";
import PropTypes from "prop-types";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";

function HomePost() {
  const name = sessionStorage.getItem("name");

  const post = {
    title: "Lifeline Insurance Ltd",
    description:
      "Lifeline Insurance Ltd's Claim Management System allows you to manage insurance requests.",
    image: "/images/admin1.avif",
    imageText: "main image description",
    linkText: "Continue reading…",
  };

  return (
    <Paper>
      <Box sx={{ position: "relative" }}>
        <Box
          sx={{
            position: "relative",
            backgroundColor: "grey.800",
            color: "#fff",
            mb: 4,
            p: 4,
            height: 500,
            backgroundSize: "cover",
            backgroundRepeat: "no-repeat",
            backgroundPosition: "center",
            backgroundImage: `url(${post.image})`,
          }}
        >
          <Typography
            variant="h4"
            gutterBottom
            align="center"
            sx={{ fontWeight: "bold", color: "#FD8D14", marginBottom: 2 }}
          >
            ADMIN PAGE
          </Typography>

          <Typography
            variant="h5"
            gutterBottom
            align="center"
            sx={{ marginBottom: 2, color:"#A8DF8E" }}
          >
            Hello, {name}!
          </Typography>
          {/* Increase the priority of the hero background image */}
          {
            <img
              style={{ display: "none", filter: "blur(20px)" }}
              src={post.image}
              alt={post.imageText}
            />
          }
          <Box
            sx={{
              position: "absolute",
              top: 0,
              bottom: 0,
              right: 0,
              left: 0,
              backgroundColor: "rgba(0,0,0,.3)",
            }}
          />
          <Grid container>
            <Grid item md={6}>
              <Box
                sx={{
                  position: "relative",
                  p: { xs: 3, md: 6 },
                  pr: { md: 0 },
                  color: "#A8DF8E",
                }}
              >
                <Typography
                  component="h2"
                  variant="h4"
                  color="inherit"
                  gutterBottom
                >
                  {post.title}
                </Typography>
                <Typography variant="h5" color="inherit" paragraph>
                  {post.description}
                </Typography>
              </Box>
            </Grid>

            <Grid item md={6}>
              <Box
                sx={{
                  position: "relative",
                  p: { xs: 3, md: 6 },
                  pr: { md: 0 },
                  color: "#CECE5A",
                }}
              >
                {/* <Typography
                  component="h1"
                  variant="h3"
                  color="inherit"
                  gutterBottom
                >
                  {post.title}
                </Typography>
                <Typography variant="h5" color="inherit" paragraph>
                  {post.description}
                </Typography> */}

                <Typography
                  component="h3"
                  variant="h4"
                  color="inherit"
                  gutterBottom
                >
                  Functionality Overview
                </Typography>

                <Typography variant="h6" color="inherit" paragraph>
                  - Provide various insurance schemes for clients. <br />-
                  Approve or cancel the registration applied by clients.
                </Typography>
                <Typography variant="h6" color="inherit" paragraph></Typography>
                {/* <Typography variant="h6" color="inherit" paragraph>

                - Access and manage incoming requests, redirecting to specific
                departments as needed.
              </Typography>
              <Typography variant="h6" color="inherit" paragraph>

                - Send notifications to clients regarding policy updates and
                other relevant information.
              </Typography> */}
              </Box>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </Paper>
  );
}

export default HomePost;
