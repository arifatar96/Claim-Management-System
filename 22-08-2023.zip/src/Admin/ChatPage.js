import React, { useState } from "react";

import {
  Container,
  Paper,
  TextField,
  IconButton,
  Divider,
  List,
  ListItem,
  ListItemText,
} from "@mui/material";

import SendIcon from "@mui/icons-material/Send";

import axios from "axios";

import { useEffect } from "react";

const ChatPage = () => {
  const [messages, setMessages] = useState([]);

  const [newMessage, setNewMessage] = useState("");
  const [clientEmail, setClientEmail] = useState("client@gmail.com");
  const adminEmail = sessionStorage.getItem("email");

  const handleSendMessage = () => {
    const data = {
      message: newMessage,
      senderMail: adminEmail,
      recieverMail: clientEmail,
    };

    const url = "http://localhost:9093/sendmessage";

    axios

      .post(url, data)

      .then((response) => {
        console.log(response.data);

        // Add the sent message to the messages state with sender 'You'

        if (newMessage.trim() !== "") {
          setMessages([...messages, { text: newMessage, sender: "You" }]);
        }

        setNewMessage("");
      })

      .catch((error) => {
        console.error("Error while Sending Data:", error);
      });
  };

  const fetchIncomingMessages = () => {
    const data = {
      senderMail: clientEmail,
      recieverMail: adminEmail,
    };

    axios

      .post("http://localhost:9093/receivemessage", data)

      .then((response) => {
        if (typeof response.data === "string" && response.data.trim() !== "") {
          // Handle a single non-empty message

          const incomingMessage = response.data;

          console.log("incoming message:", incomingMessage);

          setMessages((prevMessages) => [
            ...prevMessages,

            { text: incomingMessage, sender: "Client" },
          ]);
        }
      })

      .catch((error) => {
        console.error("Error while Fetching Incoming Messages:", error);
      });
  };

  useEffect(() => {
    // Fetch incoming messages every 5 seconds (adjust as needed)

    const intervalId = setInterval(fetchIncomingMessages, 5000);

    return () => {
      clearInterval(intervalId);
    };
  }, []);

  return (
    <Container
      maxWidth="sm"
      sx={{
        paddingTop: 2,
        display: "flex",
        flexDirection: "column",
        height: "100vh",
      }}
    >
      <Paper
        elevation={3}
        sx={{ flexGrow: 1, overflowY: "auto", marginBottom: 2, padding: 2 }}
      >
        <List>
          {messages.map((message, index) => (
            <ListItem
              key={index}
              alignItems="flex-start"
              sx={{
                alignSelf: message.sender === "You" ? "flex-end" : "flex-start",

                marginBottom: 1,

                justifyContent:
                  message.sender === "You" ? "flex-end" : "flex-start",
              }}
            >
              <ListItemText
                primary={message.text}
                secondary={message.sender}
                secondaryTypographyProps={{
                  color: "textSecondary",
                  fontSize: 12,
                }}
                sx={{
                  borderRadius: "10px",

                  backgroundColor:
                    message.sender === "You" ? "#DCF8C6" : "#E3E3E3",
                }}
              />
            </ListItem>
          ))}
        </List>
      </Paper>

      <Divider />

      <Paper
        elevation={3}
        sx={{ padding: 2, display: "flex", alignItems: "center" }}
      >
        <TextField
          variant="outlined"
          fullWidth
          placeholder="Type your message..."
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          sx={{ flexGrow: 1, marginRight: 2, borderColor: "transparent" }}
        />

        <IconButton
          onClick={handleSendMessage}
          sx={{ backgroundColor: "#3b0087", color: "white" }}
        >
          <SendIcon />
        </IconButton>
      </Paper>
    </Container>
  );
};

export default ChatPage;
