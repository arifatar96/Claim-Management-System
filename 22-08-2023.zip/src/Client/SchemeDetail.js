import React, { useEffect, useState } from "react";
import { Button,
  Box,
  Grid,
  Container,
  Typography,
  Snackbar,
  Alert,
  TextField,
  Stack, } from "@mui/material";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";

const SchemeDetails = ({ scheme, schemeName, schemeDescription }) => {
  return (
 <Container component="main" maxWidth="sm">
      <Box
        boxShadow={"5px 5px 10px grey"}
        sx={{
          margin: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Typography component="h1" variant="h5" mt={3}>
          Scheme Detail
        </Typography>

        <Box component="form" sx={{ m: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={12}>
              <TextField
                label="Scheme Name"
                  value={schemeName}
                  variant="outlined"
                  fullWidth
                  InputProps={{ readOnly: true }}
                autoFocus
              />
            </Grid>

            <Grid item xs={12} sm={12}>
                <TextField
                  label="Description"
                  value={scheme.description}
                  variant="outlined"
                  fullWidth
                  InputProps={{ readOnly: true }}
                  multiline
                  rows={4}
                />
              </Grid>

              <Grid item xs={12} sm={12}>
                <TextField
                  label="Coverage Type"
                  value={scheme.coverageType}
                  variant="outlined"
                  fullWidth
                  InputProps={{ readOnly: true }}
                />
              </Grid>

              <Grid item xs={12} sm={12}>
                <TextField
                  label="Premium Amount"
                  value={`₹ ${scheme.premiumAmount}`}
                  variant="outlined"
                  fullWidth
                  InputProps={{ readOnly: true }}
                />
              </Grid>
          </Grid>
        </Box>
      </Box>
    </Container>


    // <Container component="main" maxWidth="sm">
    //   <Box
    //     boxShadow={"5px 5px 10px grey"}
    //     sx={{
    //       margin: 8,
    //       pb: 3,
    //       display: "flex",
    //       flexDirection: "column",
    //       alignItems: "center",
    //     }}
    //   >
    //     <Typography
    //       component="h2"
    //       variant="h5"
    //       mt={3}
    //       mb={2}
    //       align="center"
    //     >
    //       Scheme Detail
    //     </Typography>

    //     <List disablePadding>
    //         <ListItem
    //           sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
    //         >
    //           <Typography
    //             variant="body1"
    //             sx={{ fontWeight: "bold", width: 180 }}
    //           >
    //             Scheme Name:
    //           </Typography>
    //           <Typography variant="body1">
    //             {schemeName}
    //           </Typography>
    //         </ListItem>
    //         <ListItem
    //           sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
    //         >
    //           <Typography
    //             variant="body1"
    //             sx={{ fontWeight: "bold", width: 180 }}
    //           >
    //             Description:
    //           </Typography>
    //           <Typography variant="body1">
    //             {schemeDescription}
    //           </Typography>
    //         </ListItem>
    //         <ListItem
    //           sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
    //         >
    //           <Typography
    //             variant="body2"
    //             sx={{ fontWeight: "bold", width: 180 }}
    //           >
    //             Coverage Type:
    //           </Typography>
    //           <Typography variant="body2">
    //             {scheme.coverageType}
    //           </Typography>
    //         </ListItem>
    //         <ListItem
    //           sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
    //         >
    //           <Typography
    //             variant="body2"
    //             sx={{ fontWeight: "bold", width: 180 }}
    //           >
    //             Premium Amount:
    //           </Typography>
    //           <Typography variant="body2">₹ {scheme.premiumAmount}</Typography>
    //         </ListItem>
    //       </List>


    //     {/* <Typography variant="h6">Scheme Name: {schemeName}</Typography>
    //     <Typography variant="body1">
    //       Description: {schemeDescription}
    //     </Typography>
    //     <Typography variant="body2" color="text.secondary">
    //       Coverage Type: {scheme.coverageType}
    //     </Typography>
    //     <Typography variant="body2" color="text.secondary">
    //       Premium Amount: ${scheme.premiumAmount}
    //     </Typography> */}
    //   </Box>
    // </Container>
  );
};

export default SchemeDetails;
