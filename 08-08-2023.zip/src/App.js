import logo from './logo.svg';
import './App.css';
import { Routes, Route } from "react-router-dom";
import { BrowserRouter as Router } from "react-router-dom";
import InsuranceSchemeManagement from './Admin/SchemeManagement';
import ClientRegistration from './Client/Registration';
import ClaimSubmission from './Client/ClaimSubmission';
import ClaimTracking from './Client/ClaimTracking';
import ClaimDetailsManagement from './System User/ClaimDetailsManagement';
import Login from './Login/Login';
import ClaimSettlement from './System User/ClaimSettlement';
import ClientFormsApproveCancel from './Admin/ClientApproveCancel';
import ModifyScheme from './Admin/ModifyScheme';
// import Navbar from './Navbar';
import InsuranceSchemeList from './Admin/ShowInsuranceschemes';
// import Navbar from './Navbar1';
import SignIn from './Login/Login1';
import AdminNavbar from './Admin/AdminNavbar';
import AdminDashboard from './Admin/AdminDashboard';
import UserDashboard from './System User/UserDashboard';
import ResponsiveAppBar from './TopNavbar1';
import Home from './Home/HomePage';
import ClientDashboard from './Client/ClientDashboard';
import HomeDashboard from './Home/HomeDashboard';
import RequestsContent from './Client/RequestContent';
import RomeChangeRequests from './System User/RomeChange';
import { useState } from 'react';
import Routing from './Router';
// import Navbar from './TopNavbar';

// import InsuranceSchemeManagement from './Admin/InsuSchmMange';


function App() {


  // const [roleName, setRoleName] = useState("");

  // var RolenameFromSessionStorage= sessionStorage.getItem("name") || " ";

  // return (

  //   <div>
  //    <Router>
  //               <Routes>
  //                   <Route path='/*' element={<HomeDashboard />} />

  //                   <Route path='/admin/*' element={<AdminDashboard />} />
  //                   {/* <Route path='admin/*' element={<AdminDashboard />} /> */}
  //                   <Route path='/user/*' element={<UserDashboard />} />
  //                   <Route path='/client/*' element={<ClientDashboard />} />
  //               </Routes>
  //           </Router>
  //   </div>
  // );

  // const roleName = sessionStorage.getItem("roleName");


  return (

    <div>


      {/* {(() => {

        switch (roleName) {

          case "ADMIN":

            return <AdminDashboard />;

          case "USER":

            return <UserDashboard />;

          case "CLIENT":

            return <ClientDashboard />;

          default:

            return <HomeDashboard />;

        }

      })()} */}
      <Router>
        <Routes>
          <Route path='/*' element={<HomeDashboard />} />
          <Route path='/admin/*' element={<AdminDashboard />} />
          {/* <Route path='admin/*' element={<AdminDashboard />} /> */}
          <Route path='/user/*' element={<UserDashboard />} />
          <Route path='/client/*' element={<ClientDashboard />} />
          {/* <Route path='/route/*' element={<Routing />} /> */}

        </Routes>
      </Router>
    </div>

  );

}







export default App;








// function App() {
//   var roleName="ADMIN"

//   var roleName="USER"

//   var roleName="CLIENT"

//   return (
//     <div className="App">
//       {/* <Login/> */}

//       {/* <InsuranceSchemeManagement/> */}

//       {/* <ClientRegistration/> */}

//       {/* <ClaimSubmission/> */}

//       {/* <ClaimTracking/> */}

//       {/* <ClaimDetailsManagement/> */}

//       {/* <ClaimSettlement/>       */}

// {/* <ClientFormsApproveCancel/> */}


//       {/* <InsuranceSchemeManagement/> */}

//       {/* <Navbar/> */}
//       {/* <InsuranceSchemeList/> */}


//       {/* <ResponsiveAppBar/>
//       <SignIn /> */}




//       {/* <UserDashboard/> */}

//       {/* <ResponsiveAppBar/> */}
//       {/* <AdminDashboard/> */}

//       <ClientDashboard/>

//       {/* <Home/> */}
// {/* 
//       <Router>
//         <ResponsiveAppBar/>
//         <Routes>
//           <Route path='/*' element={<HomeDashboard />} />
//           <Route path='/admin/*' element={<AdminDashboard />} />
//           <Route path='/user' element={<UserDashboard />} />
//           <Route path='/client' element={<ClientDashboard />} />

//         </Routes>
//       </Router> */}

//     </div>











// function App() {

//   // var roleName = "ADMIN"

//   // var roleName = "USER"

//   // var roleName = "CLIENT"

//   var roleName = ""


//   return (

//     <div>
//       {/* <RomeChangeRequests/> */}
//       {/* <RequestsContent/> */}
//       <Router>
//         {(() => {
//           if (roleName === "ADMIN") {
//             return (
//               <Routes>
//                 <Route path='/*' element={<AdminDashboard />} />
//                 {/* <Route path='admin/*' element={<AdminDashboard />} /> */}

//               </Routes>
//             );
//           }
//           else if (roleName === "USER") {
//             return (
//               <Routes>
//                 <Route path='/*' element={<UserDashboard />} />
//               </Routes>
//             )
//           }
//           else if (roleName === "CLIENT") {
//             return (
//               <Routes>
//                 <Route path='/*' element={<ClientDashboard />} />

//               </Routes>
//             )
//           }
//           else {
//             return (
//               <Routes>
//                 <Route path='/*' element={<HomeDashboard />} />

//               </Routes>
//             )
//           }
//         })()}
//       </Router>
//     </div>
//   );
// }

// export default App;
