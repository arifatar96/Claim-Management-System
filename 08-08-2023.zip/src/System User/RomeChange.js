import React, { useMemo, useState } from "react";
import { Table, Typography, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Grid, Box } from '@mui/material';
import { MaterialReactTable } from 'material-react-table';

export default function RomeChangeRequests() {

    const columns = useMemo(

        () => [
            {
                accessorKey: 'id',
                header: 'ID',
            },

            {
                accessorKey: 'claimId',
                header: 'CLAIM ID',
            },

            {
                accessorKey: 'amount',
                header: 'AMOUNT',
            },

            {
                accessorKey: 'transactionDate',
                header: 'TRANSACTION DATE',
            },

            {
                accessorKey: 'status',
                header: 'STATUS',
            },
        ],
        [], //end
    );

    const [rows, setRows] = useState([
        { id: 1, claimId: 12345, amount: 1000, transactionDate: '2023-07-25', status: 'pending' },
        { id: 2, claimId: 67890, amount: 500, transactionDate: '2023-07-26', status: 'success' },
    ]);

    const claimId = 67890;
    // sessionStorage.getItem('currentpatientid');

    const sortedRows = rows.filter(row => row.claimId === claimId);

    return (
        <React.Fragment>
            <Box
                sx={{
                    marginTop: 6,
                    alignItems: 'center',
                    boxShadow: 7,
                    p: 3
                }}
            >
                <Typography component="h2" variant="h5" mb={3} align='center'>
                    Claim Settlement Records
                </Typography>
                <Grid item xs={12} >
                    <div style={{ height: 300, width: '100%', border: 'solid 1px ' }}>
                        <MaterialReactTable
                            columns={columns}
                            data={rows}
                        />
                    </div >
                </Grid>
            </Box>
        </React.Fragment>
    )
}