
import { Routes, Route } from "react-router-dom";
import { BrowserRouter as Router } from "react-router-dom";
import UserNavbar from "./UserNavbar";
import ClaimDetailsManagement from "./ClaimDetailsManagement";
import ClaimSettlement from "./ClaimSettlement";
import ClaimSettlementRecords from "./TransactionRecords";
import RomeChangeRequests from "./RomeChange";

export default function UserDashboard() {


    return (
        <div>
            {/* <Router> */}
                <UserNavbar/>
                <Routes>
                    <Route path='/claim-requests' element={<ClaimDetailsManagement/>} />
                    <Route path='/claim-settlement' element={<ClaimSettlement/>} />
                    {/* <Route path='/records' element={<ClaimSettlementRecords/>} /> */}
                    <Route path='/records' element={<RomeChangeRequests/>} />
                
                </Routes>
            {/* </Router> */}

        </div>
    );
}
