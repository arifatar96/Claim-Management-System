import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import { Link, useNavigate } from 'react-router-dom';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import axios from 'axios';

const defaultTheme = createTheme();

const initialFormData = {

  email: '',

  password: '',

};


export default function SignIn() {
  // let navigate = useNavigate();
  // const [email, setemail] = React.useState("");
  // const [password, setpassword] = React.useState("");

  // const handleSubmit = async (e) => {

  //   try {
  //     var response = await axios(
  //       {
  //         method: "POST",
  //         url: "http://localhost:9090/login",
  //         headers: { "content-type": "application/json" },
  //         data:
  //         {
  //           email: email,
  //           password: password
  //         }

  //       })
  //   }
  //   catch (e) {
  //     console.log(e);
  //   }

  // sessionStorage.setItem("name", response.data)
  // console.log(response);

  // if (response) {
  //   console.log(response);
  // navigate("/admin/")


  //   if (response.status === 204) {
  //     alert("User credentilas not found/mismatched")
  //   }
  //   else {
  //     var roleName = response.data[0].toUpperCase();

  //     // const token=response.data[1]

  //     sessionStorage.setItem("name", roleName)
  //     // sessionStorage.setItem("token",token)
  //     // props.setRoleName(roleName)

  //   }
  // }
  // else {
  //   alert("Server conection failure");
  // }

  // console.log("Hello");
  // const account = users.find((x) => x.email === email);
  // navigate("/admin/")

  // console.log(response.data);
  //     if (response.data === "ADMIN" ) {
  //       navigate("/admin/")

  //     } 
  //     else if (response.data === "USER") {
  //       navigate("/user/")
  //     }
  // else if (roleName === "CLERK") {
  //   navigate("/clerkHomePage")
  // }
  // else if (roleName === "COP") {
  //   navigate("/copHomePage")
  // }

  // (event) => {
  //   event.preventDefault();
  //   const data = new FormData(event.currentTarget);
  //   console.log({
  //     email: data.get('email'),
  //     password: data.get('password'),
  //   });
  // };


  
   
  

  
   
  
    const navigate=useNavigate();
  
    const [formData, setFormData] = React.useState(initialFormData);
  
    const [errors, setErrors] = React.useState({});
  
   
  
    const handleInputChange = (event) => {
  
      const { name, value } = event.target;
  
      setFormData((prevData) => ({ ...prevData, [name]: value }));
  
    };
  
   
  
    const handleSubmit = async (event) => {
  
      event.preventDefault();
  
      const validationErrors = validateForm();
  
      if (Object.keys(validationErrors).length === 0) {
  
        // Form is valid, you can handle form submission here
  
        console.log('Form submitted:', formData);

  
        try
  
        {
  
          var Response=   await axios({
  
            method :"POST",
  
            url :"http://localhost:9090/login",
  
            headers:{"content-type": "application/json"},
  
            data:formData
  
          })
  
        }
  
        catch(e)
        {
  
          console.log(e)
  
        }
  
        if(Response)
  
        {
  
          const roleName=Response.data;
  
          console.log(roleName);
  
          sessionStorage.setItem('roleName',roleName)

          sessionStorage.setItem('email', formData.email)
  
          if(roleName.length<1)
  
          {
  
            alert("User Not Found");
  
          }

          // else
          // {
          //   navigate("/route/*")
          // }
  
          else
  
          {
            if(roleName==="ADMIN")
            navigate("/admin/")
            else if(roleName==="USER")
            navigate("/user/")
            else if(roleName==="CLIENT")
            navigate("/client/")
            else
            navigate("/")
  
          }
  
        }
  
        else{
  
          alert("Server Issue");
  
        }
  
   
  
        setFormData(initialFormData);
  
        //window.location.reload(true)
  
      } else {
  
        // Form has errors, display them
  
        setErrors(validationErrors);
  
      }
  
    };
  
   
  
    const validateForm = () => {
  
      const validationErrors = {};
  
   
  
      if (!formData.email) {
  
        validationErrors.email = 'Email is required';
  
      } else if (!isValidEmail(formData.email)) {
  
        validationErrors.email = 'Invalid email format';
  
      }
  
   
  
      if (!formData.password) {
  
        validationErrors.password = 'Password is required';
  
      } else if (formData.password.length < 6) {
  
        validationErrors.password = 'Password must be at least 6 characters long';
  
      }
  
   
  
   
  
      return validationErrors;
  
    };
  
   
  
    const isValidEmail = (email) => {
  
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
      return emailRegex.test(email);
  
    };

        return (
          <ThemeProvider theme={defaultTheme}>
            <Container component="main" maxWidth="xs">
              <CssBaseline />
              <Box
                boxShadow={'5px 5px 10px grey'}
                sx={{
                  padding: 4,
                  marginTop: 10,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                }}
              >
                {/* <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}>
            <LockOutlinedIcon />
          </Avatar> */}
                <Typography component="h2" variant="h5">
                  Login
                </Typography>
                <Box component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 1 }}>
                  <TextField
                    margin="normal"
                    required
                    fullWidth
                    id="email"
                    label="Email Address"
                    name="email"
                    onChange={handleInputChange}
                    autoComplete="email"
                    value={formData.email}
                    autoFocus
                  />
                  <TextField
                    margin="normal"
                    required
                    fullWidth
                    name="password"
                    label="Password"
                    type="password"
                    onChange={handleInputChange}
                    value={formData.password}
                    id="password"
                    autoComplete="current-password"
                  />
                  {/* <FormControlLabel
              control={<Checkbox value="remember" color="primary" />}
              label="Remember me"
            /> */}
                  <Button
                    type="submit"
                    fullWidth
                    variant="contained"
                    onClick={handleSubmit}
                    sx={{ mt: 3, mb: 2 }}
                  >
                    Login
                  </Button>
                  <Grid container justifyContent="flex-end">
                    {/* <Grid item xs>
                <Link href="#" variant="body2">
                  Forgot password?
                </Link>
              </Grid> */}
                    <Grid item >
                      <Link to="/signup" variant="body2">
                        {"Don't have an account? Sign Up"}
                      </Link>
                    </Grid>
                  </Grid>
                </Box>
              </Box>
              {/* <Copyright sx={{ mt: 8, mb: 4 }} /> */}
            </Container>
          </ThemeProvider>
        );
      }