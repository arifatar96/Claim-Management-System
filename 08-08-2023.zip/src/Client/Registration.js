import React, { useEffect, useState } from 'react';
import { TextField, Button, Box, Stack, Grid, Container, Typography } from '@mui/material';
import { useLocation } from 'react-router-dom';
import axios from 'axios';

const initialState = {
  firstName: '',
  lastName: '',
  dateOfBirth: '',
  address: '',
  mobileNo: '',
  pincode: '',
  pancardNo: '',
  aadharNo: '',
  email: '',
  password: '',
};

const ClientRegistration = () => {
  // State to hold the form input values
  const [data, setData] = React.useState(initialState);
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const schemeName = queryParams.get('schemeName');
  const schemeDescription = queryParams.get('schemeDescription');
  // const schemeName = new URLSearchParams(location.search).get('schemeName');
  const [schemeDetails, setSchemeDetails] = useState(null);

  const { firstName, lastName, dateOfBirth, address, mobileNo, pincode, pancardNo, aadharNo, email, password } = data;

  console.log(schemeName);
  const onChange = e => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  // Fetch the scheme details when the component mounts
  useEffect(() => {
    // Make an API call to retrieve the scheme details based on the schemeName
    axios.get(`http://localhost:9091/schemeDetails/${schemeName}`)
      .then((response) => {
        console.log(response);
        console.log(response.data);

        setSchemeDetails(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [schemeName]);

  // Handler for form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle form submission logic here (e.g., send data to the server)
    // Reset the form fields after submission
    setData(initialState);
  };

  const isFormValid = () => {
    // Check if all required fields are filled

    return (
      firstName !== '' &&
      lastName !== '' &&
      dateOfBirth !== '' &&
      mobileNo !== '' &&
      address !== '' &&
      pincode !== '' &&
      pancardNo !== '' &&
      email !== '' &&
      aadharNo !== '' &&
      isPANCardValid(pancardNo) &&
      isAadhaarCardValid(aadharNo) &&
      isEmailValid(email)
    );
  };

  const isPANCardValid = (value) => {
    const panCardRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
    return panCardRegex.test(value);
  };

  const isAadhaarCardValid = (value) => {
    const aadhaarCardRegex = /^\d{4}\s\d{4}\s\d{4}$/;
    return aadhaarCardRegex.test(value);
  };

  const isEmailValid = (value) => {
    const emailRegex = /^[\w.-]+@[a-zA-Z\d.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(value);
  };

  return (
    <Container component="main" maxWidth="md">
      <Box
        boxShadow={'5px 5px 10px grey'}
        sx={{
          margin: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Typography component="h1" variant="h5" mt={3}>
          Registration
        </Typography>

        <Box component="form" sx={{ m: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                label="First Name"
                name="firstName"
                value={firstName}
                onChange={onChange}
                required
                fullWidth
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
                label="Last Name"
                name="lastName"
                value={lastName}
                onChange={onChange}
                required
                fullWidth
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
                label="Email"
                type="email"
                name="email"
                value={email}
                onChange={onChange}
                required
                fullWidth
                error={email !== '' && !isEmailValid(email)}
                helperText={email !== '' && !isEmailValid(email) ? 'Invalid email address' : ''}
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
                label="Phone"
                name="mobileNo"
                value={mobileNo}
                onChange={onChange}
                required
                fullWidth
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                label="Date of Birth"
                type="date"
                name="dateOfBirth"
                value={dateOfBirth}
                onChange={onChange}
                required
                fullWidth
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                label="Address"
                name="address"
                value={address}
                onChange={onChange}
                required
                fullWidth
                multiline
                rows={4}
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
                label="Pincode"
                name="pincode"
                value={pincode}
                onChange={onChange}
                required
                fullWidth
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
                label="Pancard Number"
                name="pancardNo"
                value={pancardNo}
                onChange={onChange}
                required
                fullWidth
                error={pancardNo !== '' && !isPANCardValid(pancardNo)}
                helperText={pancardNo !== '' && !isPANCardValid(pancardNo) ? 'Invalid Pancard Number' : ''}
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                label="Aadhar Number"
                name="aadharNo"
                value={aadharNo}
                onChange={onChange}
                required
                fullWidth
                error={aadharNo !== '' && !isAadhaarCardValid(aadharNo)}
                helperText={aadharNo !== '' && !isAadhaarCardValid(aadharNo) ? 'Invalid Aadhar Number' : ''}
              />
            </Grid>
          </Grid>

          {schemeDetails && (
          <Typography variant="h6" sx={{ mt: 3 }}>
            Registering for Insurance Scheme: {schemeDetails.schemeName}
          </Typography>
        )}

          {/* {schemeDetails && (
            <Typography variant="h6" sx={{ mt: 3 }}>
              Registering for Insurance Scheme: {schemeDetails.schemeName}
            </Typography>
          )} */}

          <Stack spacing={2} direction="row" justifyContent="center" alignItems="center">
            <Button
              type="reset"
              variant="contained"
              sx={{ mt: 2, mb: 2, mr: 4 }}
              onClick={() => setData(initialState)}
            >
              Reset
            </Button>
            <Button
              type="submit"
              variant="contained"
              color="primary"
              disabled={!isFormValid()}
              onClick={handleSubmit}
            >
              Register
            </Button>
          </Stack>
        </Box>
      </Box>
    </Container>
  );
};

export default ClientRegistration;

