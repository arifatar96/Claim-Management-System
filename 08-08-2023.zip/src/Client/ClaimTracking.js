// Inside ClaimTracking.js
import React from 'react';
import { Box, Container, Typography } from '@mui/material';


const ClaimTracking = () => {
  // Sample data to demonstrate the claim tracking
  const claims = [
    { id: 1, claimDate: '2023-07-25', description: 'Claim for medical expenses', status: 'Approved' },
    { id: 2, claimDate: '2023-07-20', description: 'Claim for vehicle damage', status: 'Pending' },
  ];

  return (
    <Container component="main" maxWidth="sm">
      <Box
        boxShadow={'5px 5px 10px grey'}
        sx={{
          margin: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Typography component="h2" variant="h5" mt={3}>
          Claim Tracking
        </Typography>
        <Box component="ul" sx={{ padding: 0, listStyle: 'none' }}>
          {claims.map((claim) => (
            <Box component="li" key={claim.id} sx={{ margin: '10px 0' }}>
              <Typography variant="body1">
                <strong>Claim Date:</strong> {claim.claimDate}, <strong>Status:</strong> {claim.status}
              </Typography>
              <Typography variant="body2">{claim.description}</Typography>
            </Box>
          ))}
        </Box>
      </Box>
    </Container>
  );
};

export default ClaimTracking;
