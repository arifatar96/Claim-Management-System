// Inside ClaimSubmission.js
import React from 'react';
import { TextField, Button, Box, Stack, Grid, Container, Typography } from '@mui/material';

const ClaimSubmission = () => {
  // State to hold the form input values
  const [claimDate, setClaimDate] = React.useState('');
  const [description, setDescription] = React.useState('');
  const [supportingDocs, setSupportingDocs] = React.useState('');

  // Handler for form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle form submission logic here (e.g., send data to the server)
    // Reset the form fields after submission
    setClaimDate('');
    setDescription('');
    setSupportingDocs('');
  };

  return (
    <Container component="main" maxWidth="md">

      <Box
        boxShadow={'5px 5px 10px grey'}
        sx={{
          margin: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Typography component="h2" variant="h5" mt={3}>
          Apply For Claim
        </Typography>
        {/* <div>
      <h2>Claim Submission</h2>
      <form onSubmit={handleSubmit}> */}
        <Box component="form" sx={{ m: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                helperText="Claim Date"
                type="date"
                value={claimDate}
                onChange={(e) => setClaimDate(e.target.value)}
                required
                fullWidth
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
                label="Description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                fullWidth
                multiline
                rows={4}
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
              type='file'
                helperText="Supporting Documents"
                value={supportingDocs}
                onChange={(e) => setSupportingDocs(e.target.value)}
                fullWidth
                // multiline
                rows={4}
              />
            </Grid>
          </Grid>
          <Stack spacing={2} direction="row" justifyContent='center' alignItems='center'>
            <Button
              type="reset"
              variant="outlined"
              color='secondary'
              sx={{ mt: 2, mb: 2, mr: 4 }}
            // onClick={resetHandler}
            >
              Reset
            </Button>
            <Button type="submit" variant="outlined" color="primary">
              Submit
            </Button>
          </Stack>


        </Box>
        {/* </form> */}
        {/* Display the list of submitted claims for the client */}
        {/* You can map through the data and display each claim here */}
        {/* </div> */}
      </Box>
    </Container>
  );
};

export default ClaimSubmission;
