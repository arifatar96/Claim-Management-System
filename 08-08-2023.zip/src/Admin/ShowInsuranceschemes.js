// // Inside InsuranceSchemeList.js
// import React, { useEffect, useState } from 'react';
// import { Button, Box, Container, Typography, Stack, Table, TableBody, TableCell, TableHead, TableRow, Paper } from '@mui/material';
// import ModifyScheme from './ModifyScheme'; // Import the ModifyScheme component from the previous answer
// import DeleteIcon from '@mui/icons-material/Delete';
// import EditIcon from '@mui/icons-material/Edit';
// import axios from 'axios';

// const schemeDetails = () => {
//   return axios.get("http://localhost:9091/allSchemes")
//       .then((response) => response.data)
// }

// const InsuranceSchemeList = () => {
//   // Sample dummy data for insurance schemes
//   // const initialDummySchemes = [
//   //   {
//   //     id: 1,
//   //     schemeName: 'Life Insurance Plan',
//   //     description: 'This is a life insurance plan for individuals and families.',
//   //     coverageType: 'Life Coverage',
//   //     premiumAmount: 500,
//   //   },
//   //   {
//   //     id: 2,
//   //     schemeName: 'Health Insurance Plan',
//   //     description: 'This is a health insurance plan for medical coverage.',
//   //     coverageType: 'Health Coverage',
//   //     premiumAmount: 300,
//   //   },
//   //   {
//   //     id: 3,
//   //     schemeName: 'Auto Insurance Plan',
//   //     description: 'This is an auto insurance plan for vehicles.',
//   //     coverageType: 'Auto Coverage',
//   //     premiumAmount: 200,
//   //   },
//   // ];

//   const [schemes, setSchemes] = useState([]);
//   const [selectedScheme, setSelectedScheme] = useState(null);
//   const [showEditForm, setShowEditForm] = useState(false);

//   useEffect(() => {
//     // Fetch owner details when the component mounts
//     schemeDetails()
//         .then((resp) => {
//             setSchemes(resp);
//             console.log(resp);
//         })
//         .catch((error) => {
//             console.log(error);
//         });
// }, []);

//   // Function to handle updating a scheme
//   const handleUpdateScheme = (updatedScheme) => {
//     const updatedSchemes = schemes.map((scheme) =>
//       scheme.schemeName === updatedScheme.schemeName ? updatedScheme : scheme
//     );
//     setSchemes(updatedSchemes);
//     setSelectedScheme(null);
//     setShowEditForm(false);
//   };

//   // Function to handle editing a scheme
//   const handleEditScheme = (schemeName) => {
//     const schemeToEdit = schemes.find((scheme) => scheme.schemeName === schemeName);
//     setSelectedScheme(schemeToEdit);
//     setShowEditForm(true);
//   };

//   // Function to handle deleting a scheme
//   const handleDeleteScheme = (schemeName) => {
//     const updatedSchemes = schemes.filter((scheme) => scheme.schemeName !== schemeName);
//     setSchemes(updatedSchemes);
//     setSelectedScheme(null);
//     setShowEditForm(false);
//   };

//   return (
//     <Container component="main" maxWidth="lg" >
//       {/* <div> */}

//       <Typography component="h2" variant="h5" mt={6} mb={3} align="center">
//         Insurance Scheme List
//       </Typography>
//       {/* <h2>Insurance Scheme List</h2> */}
//         <Paper elevation={3}>
//           <Table >
//             <TableHead>
//               <TableRow>
//                 <TableCell>Scheme Name</TableCell>
//                 <TableCell>Description</TableCell>
//                 <TableCell>Coverage Type</TableCell>
//                 <TableCell>Premium Amount</TableCell>
//                 <TableCell colSpan={2} align='center'>Action</TableCell>
//               </TableRow>
//             </TableHead>
//             <TableBody>
//               {schemes.map((scheme) => (
//                 <TableRow key={scheme.schemeName}>
//                   <TableCell>{scheme.schemeName}</TableCell>
//                   <TableCell>{scheme.description}</TableCell>
//                   <TableCell>{scheme.coverageType}</TableCell>
//                   <TableCell>{scheme.premiumAmount}</TableCell>
//                   <TableCell align='center'>
//                     {/* <Stack spacing={2} direction="row" justifyContent='center' alignItems='center'> */}
//                       <Button variant="outlined" color="secondary" onClick={() => handleEditScheme(scheme.schemeName)} startIcon={<EditIcon />}>
//                         Edit
//                       </Button>
//                       </TableCell>
//                       <TableCell align='center'>
//                       <Button variant="outlined" color="error" onClick={() => handleDeleteScheme(scheme.schemeName)} startIcon={<DeleteIcon />}>
//                         Delete
//                       </Button>
//                     {/* </Stack> */}
//                   </TableCell>
//                 </TableRow>
//               ))}
//             </TableBody>
//           </Table>
//         </Paper>

//       {/* If showEditForm is true and there is a selectedScheme, display the edit form */}
//       {showEditForm && selectedScheme && (
//         <ModifyScheme
//           existingScheme={selectedScheme} // Pass the selectedScheme to the ModifyScheme component
//           updateScheme={handleUpdateScheme}
//           deleteScheme={handleDeleteScheme}
//         />
//       )}

//       {/* </div> */}

//     </Container>
//   );
// };

// export default InsuranceSchemeList;



// import React, { useEffect, useState } from 'react';
// import { Button, Box, Container, Typography, Table, TableBody, TableCell, TableHead, TableRow, Paper } from '@mui/material';
// import ModifyScheme from './ModifyScheme';
// import DeleteIcon from '@mui/icons-material/Delete';
// import EditIcon from '@mui/icons-material/Edit';
// import axios from 'axios';

// const schemeDetails = () => {
//   return axios.get("http://localhost:9091/allSchemes")
//     .then((response) => response.data)
// }

// const InsuranceSchemeList = () => {
//   const [schemes, setSchemes] = useState([]);
//   const [selectedScheme, setSelectedScheme] = useState(null);
//   const [showEditForm, setShowEditForm] = useState(false);
//   const [openSnackbar, setOpenSnackbar] = useState(false);
//   const [alertMessage, setAlertMessage] = useState('');

//   useEffect(() => {
//     schemeDetails()
//       .then((resp) => {
//         setSchemes(resp);
//         console.log(resp);
//       })
//       .catch((error) => {
//         console.log(error);
//       });
//   }, []);

//   const handleUpdateScheme = (updatedScheme) => {
//     const updatedSchemes = schemes.map((scheme) =>
//       scheme.schemeName === updatedScheme.schemeName ? updatedScheme : scheme
//     );
//     setSchemes(updatedSchemes);
//     setSelectedScheme(null);
//     setShowEditForm(false);
//   };

//   const handleEditScheme = (schemeName) => {
//     const schemeToEdit = schemes.find((scheme) => scheme.schemeName === schemeName);
//     setSelectedScheme(schemeToEdit);
//     setShowEditForm(true);
//   };

//   const handleDeleteScheme = (schemeName) => {
//     const updatedSchemes = schemes.filter((scheme) => scheme.schemeName !== schemeName);
//     setSchemes(updatedSchemes);
//     setSelectedScheme(null);
//     setShowEditForm(false);
//   };

//   const handleDelete = () => {
//     // const deleteDetails = {
//     //   schemeName,
//     //   description,
//     //   coverageType,
//     //   premiumAmount,
//     // };
//     axios.delete("http://localhost:9091/deleteScheme", {
//       data: selectedScheme,
//       headers: {
//         "Content-Type": "application/json",
//         "Accept": "application/json",
//       }
//     })
//     .then((resp) => {
//       setAlertMessage(`deleted successfully`);
//       setOpenSnackbar(true);
//       console.log(resp);
//       handleDeleteScheme(selectedScheme);
//     })
//     .catch((error) => {
//       console.log(error);
//     });
//   };

//   return (
//     <Container component="main" maxWidth="lg">
//       <Typography component="h2" variant="h5" mt={6} mb={3} align="center">
//         Insurance Scheme List
//       </Typography>
//       <Paper elevation={3}>
//         <Table>
//           <TableHead>
//             <TableRow>
//               <TableCell>Scheme Name</TableCell>
//               <TableCell>Description</TableCell>
//               <TableCell>Coverage Type</TableCell>
//               <TableCell>Premium Amount</TableCell>
//               <TableCell colSpan={2} align='center'>Action</TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {schemes.map((scheme) => (
//               <TableRow key={scheme.schemeName}>
//                 <TableCell>{scheme.schemeName}</TableCell>
//                 <TableCell>{scheme.description}</TableCell>
//                 <TableCell>{scheme.coverageType}</TableCell>
//                 <TableCell>{scheme.premiumAmount}</TableCell>
//                 <TableCell align='center'>
//                   <Button variant="outlined" color="secondary" onClick={() => handleEditScheme(scheme.schemeName)} startIcon={<EditIcon />}>
//                     Edit
//                   </Button>
//                 </TableCell>
//                 <TableCell align='center'>
//                   <Button variant="outlined" color="error" onClick={handleDelete} startIcon={<DeleteIcon />}>
//                     Delete
//                   </Button>
//                 </TableCell>
//               </TableRow>
//             ))}
//           </TableBody>
//         </Table>
//       </Paper>
//       {showEditForm && selectedScheme && (
//         <ModifyScheme
//           existingScheme={selectedScheme}
//           handleUpdateScheme={handleUpdateScheme}
//           handleDeleteScheme={handleDeleteScheme}
//         />
//       )}
//     </Container>
//   );
// };

// export default InsuranceSchemeList;





import React, { useEffect, useState } from 'react';
import { Button, Box, Container, Typography, Table, TableBody, TableCell, TableHead, TableRow, Paper, Snackbar, Alert } from '@mui/material';
import ModifyScheme from './ModifyScheme';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import axios from 'axios';

const schemeDetails = () => {
  return axios.get("http://localhost:9091/allSchemes")
    .then((response) => response.data)
}

const InsuranceSchemeList = () => {
  const [schemes, setSchemes] = useState([]);
  const [selectedScheme, setSelectedScheme] = useState([]);
  const [showEditForm, setShowEditForm] = useState(false);
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');

  useEffect(() => {
    schemeDetails()
      .then((resp) => {
        setSchemes(resp);
        console.log(resp);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const handleUpdateScheme = (updatedScheme) => {
    const updatedSchemes = schemes.map((scheme) =>
      scheme.schemeName === updatedScheme.schemeName ? updatedScheme : scheme
    );
    setSchemes(updatedSchemes);
    setSelectedScheme(null);
    setShowEditForm(false);
  };

  const handleEditScheme = (schemeName) => {
    const schemeToEdit = schemes.find((scheme) => scheme.schemeName === schemeName);
    console.log(schemeToEdit);
    setSelectedScheme(schemeToEdit);
    console.log(selectedScheme);
    setShowEditForm(true);
  };

  const handleDeleteScheme = (schemeName) => {
    const updatedSchemes = schemes.filter((scheme) => scheme.schemeName !== schemeName);
    setSchemes(updatedSchemes);
    setSelectedScheme(null);
    setShowEditForm(false);
  };

  const handleDelete = (schemeName) => {
    const schemeToDelete = schemes.find((scheme) => scheme.schemeName === schemeName);
    // setSelectedScheme(schemeToDelete);

    console.log("Deleting scheme:", selectedScheme);

    axios.delete("http://localhost:9091/deleteScheme", {
      data: schemeToDelete,
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
      }
    })
    .then((resp) => {
      console.log("Deletion response:", resp);
      setAlertMessage(`${schemeToDelete.schemeName} details deleted successfully`);
      setOpenSnackbar(true);
      handleDeleteScheme(schemeToDelete.schemeName);
    })
    .catch((error) => {
      console.log("Deletion error:", error);
    });
  };
  

  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };

  return (
    <Container component="main" maxWidth="lg">
      <Typography component="h2" variant="h5" mt={6} mb={3} align="center">
        Insurance Scheme List
      </Typography>
      <Paper elevation={3}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Scheme Name</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Coverage Type</TableCell>
              <TableCell>Premium Amount</TableCell>
              <TableCell colSpan={2} align='center'>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {schemes.map((scheme) => (
              <TableRow key={scheme.schemeName}>
                <TableCell>{scheme.schemeName}</TableCell>
                <TableCell>{scheme.description}</TableCell>
                <TableCell>{scheme.coverageType}</TableCell>
                <TableCell>{scheme.premiumAmount}</TableCell>
                <TableCell align='center'>
                  <Button variant="outlined" color="secondary" onClick={() => handleEditScheme(scheme.schemeName)} startIcon={<EditIcon />}>
                    Edit
                  </Button>
                </TableCell>
                <TableCell align='center'>
                  <Button variant="outlined" color="error" onClick={() => handleDelete(scheme.schemeName)} startIcon={<DeleteIcon />}>
                    Delete
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
      {showEditForm && selectedScheme && (
        <ModifyScheme
          existingScheme={selectedScheme}
          handleUpdateScheme={handleUpdateScheme}
          handleDeleteScheme={handleDeleteScheme}
        />
      )}
      <Snackbar
        open={openSnackbar}
        autoHideDuration={3000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert onClose={handleCloseSnackbar} severity="success">
          {alertMessage}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default InsuranceSchemeList;
