import { Routes, Route } from "react-router-dom";
import { BrowserRouter as Router } from "react-router-dom";
import AdminNavbar from "./AdminNavbar";
import InsuranceSchemeManagement from "./SchemeManagement";
import InsuranceSchemeList from "./ShowInsuranceschemes";
import ClientFormsApproveCancel from "./ClientApproveCancel";
import ModifyScheme from "./ModifyScheme";
import AdminQueryPage from "./AdminQueryPage";
import ClaimDetailsManagement from "./ClaimDetailsManagement";
import Home from "../Home/HomePage";
import SignIn from "../Login/Login1";

export default function AdminDashboard() {


    return (
        <div>
            {/* <Router> */}
                <AdminNavbar/>
                <Routes>
                {/* <Route path='/' element={<InsuranceSchemeManagement/>} /> */}

                    <Route path='/add-scheme' element={<InsuranceSchemeManagement/>} />
                    <Route path='/scheme-list' element={<InsuranceSchemeList/>} />
                    <Route path='/client-forms' element={<ClientFormsApproveCancel/>} />
                    <Route path='/claim-requests' element={<ClaimDetailsManagement/>} />
                    <Route path='/client-querries' element={<AdminQueryPage/>} />
                    {/* <Route path='/login' element={<SignIn/>}/> */}
                </Routes>
            {/* </Router> */}

        </div>
    );
}
