// Inside ClientFormsApproveCancel.js
import React, { useState } from 'react';
import { Button, Stack, Table, Container, Typography, TableBody, TableCell, TableHead, TableRow, Paper } from '@mui/material';
import VerifiedUserOutlinedIcon from '@mui/icons-material/VerifiedUserOutlined';
import ThumbDownAltOutlinedIcon from '@mui/icons-material/ThumbDownAltOutlined';

const ClientFormsApproveCancel = () => {
  // Sample data to demonstrate pending client registrations
  const [pendingRegistrations, setPendingRegistrations] = useState([
    { id: 1, clientName: 'John Doe', policyType: 'Life Insurance', registrationDate: '2023-07-25' },
    { id: 2, clientName: 'Jane Smith', policyType: 'Health Insurance', registrationDate: '2023-07-26' },
  ]);

  // Handler for approving a client registration
  const handleApproveRegistration = (registrationId) => {
    // Handle client registration approval logic here (e.g., send approval request to the server)
    // Update the pendingRegistrations state after successful approval
    // setPendingRegistrations([...updatedRegistrations]);
  };

  // Handler for canceling a client registration
  const handleCancelRegistration = (registrationId) => {
    // Handle client registration cancellation logic here (e.g., send cancellation request to the server)
    // Update the pendingRegistrations state after successful cancellation
    // setPendingRegistrations([...updatedRegistrations]);
  };

  return (
    <Container component="main" maxWidth="md">

      {/* <div> */}
      <Typography component="h2" variant="h5" mt={6} mb={3} align='center'>
        Client Forms Approve/Cancel
      </Typography>
      {/* <h2>Client Forms Approve/Cancel</h2> */}
      <Paper>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Client Name</TableCell>
              <TableCell>Policy Type</TableCell>
              <TableCell>Registration Date</TableCell>
              <TableCell colSpan={2} align='center'>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {pendingRegistrations.map((registration) => (
              <TableRow key={registration.id}>
                <TableCell>{registration.id}</TableCell>
                <TableCell>{registration.clientName}</TableCell>
                <TableCell>{registration.policyType}</TableCell>
                <TableCell>{registration.registrationDate}</TableCell>
                <TableCell align='center'>
                  {/* <Stack spacing={2} direction="row" justifyContent='center' alignItems='center'> */}
                  <Button variant="outlined" startIcon={<VerifiedUserOutlinedIcon/>} color="primary" onClick={() => handleApproveRegistration(registration.id)}>
                    Approve
                  </Button>
                </TableCell>
                <TableCell align='center'>
                  <Button variant="outlined" startIcon={<ThumbDownAltOutlinedIcon/>} color="error" onClick={() => handleCancelRegistration(registration.id)}>
                    Reject
                  </Button>
                  {/* </Stack> */}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
      {/* </div> */}
    </Container>
  );
};

export default ClientFormsApproveCancel;
