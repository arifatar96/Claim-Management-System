// Inside ClaimDetailsManagement.js
import React from 'react';
import { TextField, Button, Box, Stack, Grid, Container, Typography } from '@mui/material';

const ClaimDetailsManagement = () => {
  // Sample data to demonstrate the claim details management
  const claimDetails = {
    claimDate: '2023-07-25',
    description: 'Claim for medical expenses',
    clientName: 'John Doe',
    policyNumber: 'PL123456',
  };

  // State to hold the form input values
  const [updateDescription, setUpdateDescription] = React.useState('');

  // Handler for form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle form submission logic here (e.g., send data to the server)
    // Reset the form fields after submission
    setUpdateDescription('');
  };

  return (
    <Container component="main" maxWidth="md">

      <Box
        boxShadow={'5px 5px 10px grey'}
        sx={{
          margin: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Typography component="h2" variant="h5" mt={3}>
        Claim Details Management
        </Typography>

        <Typography component="h3" variant="h5" mt={3}>
        Claim Details
        </Typography>
    {/* <div> */}
      {/* <h2>Claim Details Management</h2>
      <h3>Claim Details</h3> */}
      <p>
        <strong>Claim Date:</strong> {claimDetails.claimDate}, <strong>Description:</strong> {claimDetails.description}
      </p>
      <p>
        <strong>Client Name:</strong> {claimDetails.clientName}, <strong>Policy Number:</strong> {claimDetails.policyNumber}
      </p>
      <Box component="form" sx={{ m: 3 }}>
          <Grid container spacing={2}>
            {/* <Grid item xs={12} sm={6}> */}
      {/* <form onSubmit={handleSubmit}> */}
        <TextField
          label="Update Description"
          value={updateDescription}
          onChange={(e) => setUpdateDescription(e.target.value)}
          required
          fullWidth
          multiline
          rows={4}
        />
        {/* </Grid> */}
            </Grid>
            <Stack spacing={2} direction="row" justifyContent='center' alignItems='center' sx={{ mt: 2, mb: 2 }}>
              <Button
                type="reset"
                variant="outlined"
                color='error'
                
              // onClick={resetHandler}
              >
                Reset
              </Button>
        <Button type="submit" variant="outlined" color="primary">
          Add Update
        </Button>
        </Stack>


        </Box>
      {/* </form> */}
      {/* Display the history of updates on the claim */}
      {/* You can map through the data and display each update here */}
    {/* </div> */}
    </Box>
    </Container>
  );
};

export default ClaimDetailsManagement;
