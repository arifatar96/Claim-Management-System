import React from "react";
import { Typography, Button, Grid, Paper } from "@mui/material";

const Home = () => {
  return (
    <Grid container spacing={3} justifyContent="center" alignItems="center">
      <Grid item xs={12}>
        <Paper elevation={3} sx={{ padding: 3, marginTop: 7, backgroundColor: '#D8D9DA' }}>
          <Typography variant="h4" gutterBottom align="center">
            Welcome to Claim Management System
          </Typography>
          <Typography variant="body1" gutterBottom align="center">
            This system helps you manage claims efficiently and securely.
          </Typography>
          {/* <Button variant="contained" color="primary" sx={{ marginTop: 2 }}>
            Get Started
          </Button> */}
        </Paper>
      </Grid>
      <Grid item xs={12} sm={6}>
        <Paper elevation={3} sx={{ padding: 3, backgroundColor: '#D8D9DA'}}>
          <Typography variant="h6" gutterBottom>
            About Us
          </Typography>
          <Typography variant="body2" gutterBottom>
            Our company is committed to providing the best claim management
            services to our customers.
          </Typography>
          {/* <Button variant="outlined" color="primary" sx={{ marginTop: 2 }}>
            Learn More
          </Button> */}
        </Paper>
      </Grid>
      <Grid item xs={12} sm={6}>
        <Paper elevation={3} sx={{ padding: 3, backgroundColor: '#D8D9DA' }}>
          <Typography variant="h6" gutterBottom>
            Contact Us
          </Typography>
          <Typography variant="body2" gutterBottom>
            Have questions or need support? Feel free to reach out to us.
          </Typography>
          {/* <Button variant="outlined" color="primary" sx={{ marginTop: 2 }}>
            Contact Now
          </Button> */}
        </Paper>
      </Grid>
    </Grid>
  );
};

export default Home;
