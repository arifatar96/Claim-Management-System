import React, { useEffect, useState } from "react";
import { Box, Container, Typography } from "@mui/material";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";

const SchemeDetails = ({ scheme, schemeName, schemeDescription }) => {
  return (
    <Container component="main" maxWidth="sm">
      <Box
        boxShadow={"5px 5px 10px grey"}
        sx={{
          margin: 8,
          pb: 3,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Typography
          component="h2"
          variant="h5"
          mt={3}
          mb={2}
          align="center"
        >
          Scheme Detail
        </Typography>

        <List disablePadding>
            <ListItem
              sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
            >
              <Typography
                variant="body1"
                sx={{ fontWeight: "bold", width: 180 }}
              >
                Scheme Name:
              </Typography>
              <Typography variant="body1">
                {schemeName}
              </Typography>
            </ListItem>
            <ListItem
              sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
            >
              <Typography
                variant="body1"
                sx={{ fontWeight: "bold", width: 180 }}
              >
                Description:
              </Typography>
              <Typography variant="body1">
                {schemeDescription}
              </Typography>
            </ListItem>
            <ListItem
              sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
            >
              <Typography
                variant="body2"
                sx={{ fontWeight: "bold", width: 180 }}
              >
                Coverage Type:
              </Typography>
              <Typography variant="body2">
                {scheme.coverageType}
              </Typography>
            </ListItem>
            <ListItem
              sx={{ py: 1, px: 0, display: "flex", alignItems: "center" }}
            >
              <Typography
                variant="body2"
                sx={{ fontWeight: "bold", width: 180 }}
              >
                Premium Amount:
              </Typography>
              <Typography variant="body2">₹ {scheme.premiumAmount}</Typography>
            </ListItem>
          </List>


        {/* <Typography variant="h6">Scheme Name: {schemeName}</Typography>
        <Typography variant="body1">
          Description: {schemeDescription}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Coverage Type: {scheme.coverageType}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Premium Amount: ${scheme.premiumAmount}
        </Typography> */}
      </Box>
    </Container>
  );
};

export default SchemeDetails;
