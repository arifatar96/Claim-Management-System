import React from "react";
import {
  Container,
  Typography,
  Button,
  Card,
  CardContent,
} from "@mui/material";

const HomePage = () => {
  const name = sessionStorage.getItem("name");

  const containerStyle = {
    marginTop: "20px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  };

  const bannerImageStyle = {
    width: "100%",
    maxHeight: "500px", // Adjust the height as needed
  };

  const cardStyle = {
    maxWidth: "400px",
    margin: "10px",
  };

  return (
    <Container component="main" maxWidth="md" style={containerStyle}>
      <Typography variant="h4" gutterBottom align="center" m={2}>
        Welcome, {name}!
      </Typography>

      <img
        src="/images/userbanner.jpg" // Change the path to your image
        alt="Banner"
        style={bannerImageStyle}
      />

      {/* <Card style={cardStyle}>
        <CardContent>
          <Typography variant="h6" component="h2" gutterBottom>
            Welcome, Admin!
          </Typography>
          <Typography variant="body1" gutterBottom>
            Lifeline Insurance Ltd's Claim Management System allows you to manage insurance requests and notifications.
          </Typography>
          <Button variant="contained" color="primary" fullWidth>
            View Insurance Schemes
          </Button>
          <Button variant="contained" color="secondary" fullWidth>
            Manage Requests
          </Button>
          <Button variant="contained" color="info" fullWidth>
            Send Notifications
          </Button>
        </CardContent>
      </Card> */}
    </Container>
  );
};

export default HomePage;
