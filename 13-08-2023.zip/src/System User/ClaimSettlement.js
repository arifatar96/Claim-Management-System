import React, { useState } from 'react';
import { TextField, Button, Box, Stack, Grid, Container, Typography } from '@mui/material';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';

const ClaimSettlement = () => {
  // State to hold the form input values
  const [claimId, setClaimId] = useState('');
  const [amount, setAmount] = useState('');
  const [transactionDate, setTransactionDate] = useState('');

  // Handler for form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle claim settlement submission logic here (e.g., send data to the server)
    // Reset the form fields after submission
    setClaimId('');
    setAmount('');
    setTransactionDate('');
  };

  return (
    <Container component="main" maxWidth="md">
      <Box
        boxShadow={'5px 5px 10px grey'}
        sx={{
          margin: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Typography component="h1" variant="h5" mt={3}>
          Claim Settlement
        </Typography>
        <Box component="form" sx={{ m: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                label="Claim ID"
                value={claimId}
                onChange={(e) => setClaimId(e.target.value)}
                required
                fullWidth
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
                label="Amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
                fullWidth
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <TextField
                helperText="Transaction Date"
                type="date"
                value={transactionDate}
                onChange={(e) => setTransactionDate(e.target.value)}
                required
                fullWidth
              />
            </Grid>
          </Grid>
          <Stack spacing={2} direction="row" justifyContent="center" alignItems="center" sx={{ mt: 2, mb: 2 }}>
            <Button type="reset" color="error" variant="outlined" >
              Reset
            </Button>
            <Button type="submit" variant="outlined" color="primary" onClick={handleSubmit} endIcon={<ArrowForwardIcon/>}>
              Process
            </Button>
          </Stack>
        </Box>
      </Box>
    </Container>
  );
};

export default ClaimSettlement;
