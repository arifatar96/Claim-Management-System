import React, { useEffect, useState } from "react";
import { Container, Typography } from "@mui/material";

const SchemeDetails = ({ scheme, schemeName, schemeDescription }) => {
  return (
    <Container component="main" maxWidth="md">
      <Typography component="h2" variant="h5" mt={6} mb={3} align="center">
        Scheme Details
      </Typography>
      <Typography variant="h6">Scheme Name: {schemeName}</Typography>
      <Typography variant="body1">Description: {schemeDescription}</Typography>
      <Typography variant="body2" color="text.secondary">
        Coverage Type: {scheme.coverageType}
      </Typography>
      <Typography variant="body2" color="text.secondary">
        Premium Amount: ${scheme.premiumAmount}
      </Typography>
      {/* Add more details here */}
    </Container>
  );
};

export default SchemeDetails;
