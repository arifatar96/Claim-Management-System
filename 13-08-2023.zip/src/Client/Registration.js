import React, { useEffect, useState } from "react";
import {
  TextField,
  Button,
  Box,
  Stack,
  Grid,
  Container,
  Typography,
  Snackbar,
  Alert,
} from "@mui/material";
import { useLocation } from "react-router-dom";
import axios from "axios";
import HowToRegIcon from "@mui/icons-material/HowToReg";

const ClientRegistration = () => {
  // State to hold the form input values

  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const schemeName = queryParams.get("schemeName");
  const schemeDescription = queryParams.get("schemeDescription");
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [alertMes, setAlertMes] = useState("");
  const [openSuccessSnackbar, setOpenSuccessSnackbar] = useState(false);
  const [openErrorSnackbar, setOpenErrorSnackbar] = useState(false);
  const [alertMessage, setAlertMessage] = useState("");
  
  // const schemeName = new URLSearchParams(location.search).get('schemeName');
  const [schemeDetails, setSchemeDetails] = useState(null);

  const email = sessionStorage.getItem("email");

  console.log(schemeName);

  // Fetch the scheme details when the component mounts
  useEffect(() => {
    // Make an API call to retrieve the scheme details based on the schemeName
    axios
      .get(`http://localhost:9091/schemeDetails/${schemeName}`)
      .then((response) => {
        console.log(response);
        console.log(response.data);

        setSchemeDetails(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [schemeName]);

  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };

  const regDetails = (data) => {
    return axios
      .post("http://localhost:9093/addRegistration", data, {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      })
      .then((response) => response.data);
  };

  // Handler for form submission
  const handleSubmit = (event) => {
    event.preventDefault();

    const currentDate = new Date().toISOString().split("T")[0];

    const data = {
      email: email,
      schemeName: schemeName,
      registrationDate: currentDate,
      status: "pending",
    };

    regDetails(data)
    .then((resp) => {
      if (resp === "Success") {
        setAlertMessage(
          `Registered for ${data.schemeName} successfully`
        );
        setOpenSuccessSnackbar(true);
        setOpenErrorSnackbar(false); // Close the error snackbar if it's open
      } else {
        setAlertMessage(
          `Registered for ${data.schemeName} Failed`
        );
        setOpenErrorSnackbar(true);
        setOpenSuccessSnackbar(false); // Close the success snackbar if it's open
      }
    })
    .catch((error) => {
      console.log(error);
    });
  


    // regDetails(data) // Use editableData for submission
    //   .then((resp) => {
    //     if (resp === "Success") {
    //       setAlertMessage(`Registered for ${data.schemeName} successfully`);
    //       setOpenSnackbar(true);
    //       console.log(resp);
    //     } else {
    //       setAlertMes(`Registered for ${data.schemeName} Failed`);
    //       setOpenSnackbar(true);
    //     }
    //   })
    //   .catch((error) => {
    //     console.log(error);
    //   });

  };

  return (
    <Container component="main" maxWidth="md">
      <Box
        boxShadow={"5px 5px 10px grey"}
        sx={{
          margin: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Typography component="h1" variant="h5" mt={3}>
          Registration
        </Typography>

        <Box component="form" sx={{ m: 2 }}>
          {schemeDetails && (
            <Box>
              <Typography component="h6" variant="h6" sx={{ mt: 1 }}>
                Scheme Name : {schemeDetails.schemeName}
              </Typography>
              <Typography variant="body1">
                Description: {schemeDetails.description}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Coverage Type: {schemeDetails.coverageType}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Premium Amount: {schemeDetails.premiumAmount}
              </Typography>
            </Box>
          )}

          <Stack
            spacing={2}
            direction="row"
            justifyContent="center"
            alignItems="center"
            sx={{ mt: 2, mb: 2, mr: 4 }}
          >
            <Button
              type="submit"
              startIcon={<HowToRegIcon />}
              variant="outlined"
              color="primary"
              onClick={handleSubmit}
            >
              Register
            </Button>
          </Stack>
        </Box>
      </Box>

      <Snackbar
        open={openSuccessSnackbar}
        autoHideDuration={3000}
        onClose={() => setOpenSuccessSnackbar(false)}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
      >
        <Alert onClose={() => setOpenSuccessSnackbar(false)} severity="success">
          {alertMessage}
        </Alert>
      </Snackbar>

      <Snackbar
        open={openErrorSnackbar}
        autoHideDuration={3000}
        onClose={() => setOpenErrorSnackbar(false)}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
      >
        <Alert onClose={() => setOpenErrorSnackbar(false)} severity="error">
          {alertMessage}
        </Alert>
      </Snackbar>

      {/* <Snackbar
        open={openSnackbar}
        autoHideDuration={3000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
      >
        <Alert onClose={handleCloseSnackbar} severity="success">
          {alertMessage}
        </Alert>
      </Snackbar>

      <Snackbar
        open={openSnackbar}
        autoHideDuration={3000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
      >
        <Alert onClose={handleCloseSnackbar} severity="error">
          {alertMes}
        </Alert>
      </Snackbar> */}
    </Container>
  );
};

export default ClientRegistration;
