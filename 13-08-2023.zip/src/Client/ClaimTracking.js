import React, { useEffect, useState } from "react";
import axios from "axios";
import { Button, Box, Container, Typography, Table, TableBody, TableCell, TableHead, TableRow, Paper, Snackbar, Alert } from '@mui/material';


const claimDetails = () => {
  return axios.get(`http://localhost:9093/allClaims`)
    .then((response) => response.data)
}

const ClaimTracking = () => {
  const [claims, setClaims] = useState([]);
  const email = sessionStorage.getItem('email');


  // const claims = [
  //   { id: 1, claimDate: '2023-07-25', description: 'Claim for medical expenses', status: 'Approved' },
  //   { id: 2, claimDate: '2023-07-20', description: 'Claim for vehicle damage', status: 'Pending' },
  // ];


  useEffect(() => {
    claimDetails()
      .then((resp) => {
        const allClaims = resp.filter(claim => claim.email === email);
        setClaims(allClaims);
        console.log(allClaims);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);



  // window.addEventListener("unload", (event) => {
  //   getClaims();
  // });

  // useEffect(() => {
  //   getClaims();
  // }, []);

  // const getClaims = async() => {
  //   console.log("Fetching claim details...");
  //   await axios 
  //     .get(`http://localhost:9093/claimDetail/${email}`)
  //     .then((response) => {

  //       console.log("Claim details fetched:", response.data);
  //       setClaims(response.data);
  //       console.log(response);
  //     })
  //     .catch((error) => {
  //       console.log("Error fetching claim details:", error);
  //     });
  // };

  

  return (
    <Container component="main" maxWidth="md">
      <Box
        boxShadow={'5px 5px 10px grey'}
        sx={{
          margin: 8,
          pb:3,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Typography component="h2" variant="h5" mt={3} mb={3} align="center">
          Claim Tracking
        </Typography>


        {/* <Paper elevation={3}> */}
        <Table>
          <TableHead>
            <TableRow>
              <TableCell sx={{ fontWeight: 'bold' }}>Scheme Name</TableCell>
              <TableCell sx={{ fontWeight: 'bold' }}>Applied Date</TableCell>
              <TableCell sx={{ fontWeight: 'bold' }}>Claim Percentage</TableCell>
              <TableCell sx={{ fontWeight: 'bold' }}>Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {claims.map((claim) => (
              <TableRow key={claim.id}>
                <TableCell>{claim.schemeName}</TableCell>
                <TableCell>{claim.claimDate.split("T")[0]}</TableCell>
                <TableCell>{claim.claimPercentage}%</TableCell>
                <TableCell>{claim.claimStatus}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      {/* </Paper> */}



{/* 
        {claims.map((claim) => (
          <div key={claim.id}>
      <Typography variant="h6">Scheme Name: {claim.schemeName}</Typography>
      <Typography variant="body1">Claim Date: {claim.claimDate.split("T")[0]}</Typography>
      <Typography variant="body2" color="text.secondary">
      Status: {claim.claimStatus}
      </Typography>
      </div>
      ))} */}



        {/* <Box component="ul" sx={{ padding: 0, listStyle: 'none' }}>
          {claims.map((claim) => (
            <Box component="li"  sx={{ margin: '10px 0' }}>
              <Typography variant="body1">
              Scheme Name:{claim.schemeName} Claim Date: {claim.claimDate.split("T")[0]} Status:{claim.claimStatus}
              </Typography>
              <Typography variant="body2">
              <strong>Scheme Name:</strong> {claim.schemeName}
                {claim.description}</Typography>
            </Box>
          ))}
        </Box> */}
      </Box>
    </Container>
  );
};

export default ClaimTracking;
