import React from "react";
import {
  TextField,
  Button,
  Box,
  Stack,
  Grid,
  Container,
  Typography,
} from "@mui/material";
import VerifiedUserOutlinedIcon from "@mui/icons-material/VerifiedUserOutlined";
import ThumbDownAltOutlinedIcon from "@mui/icons-material/ThumbDownAltOutlined";

const ClaimView = ({
  existingClaim,
  handleApproveClaim,
  handleRejectClaim,
}) => {
  // Sample data to demonstrate the claim details management
  // const existingClaim = {
  //   claimDate: "2023-07-25",
  //   description: "Claim for medical expenses",
  //   clientName: "John Doe",
  //   policyNumber: "PL123456",
  // };

  // State to hold the form input values
  const [updateDescription, setUpdateDescription] = React.useState("");

  // Handler for form submission
  const handleSubmit = (event) => {
    event.preventDefault();
    // Handle form submission logic here (e.g., send data to the server)
    // Reset the form fields after submission
    // setUpdateDescription("");
  };

  // const arif = () => {
  //   console.log(existingClaim);
  //   console.log(updateDescription);
  //   const data = {
  //     ...existingClaim,
  //     adminUpdate : updateDescription
  //   } 
  //   handleApproveClaim(data)
  // }

  return (
    <Container component="main" maxWidth="md">
      <Box
        boxShadow={"5px 5px 10px grey"}
        sx={{
          margin: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        {/* <Typography component="h2" variant="h5" mt={3}>
          Claim Details Management
        </Typography> */}

        <Typography component="h2" variant="h5" mt={3}>
          Claim Details
        </Typography>

        <p>
          <strong>Scheme Name:</strong> {existingClaim.schemeName},{" "}
          <strong>Claim Date:</strong> {existingClaim.claimDate.split("T")[0]}
        </p>
        <p>
          <strong>Client Name:</strong> {existingClaim.email},{" "}
          <strong>Reason:</strong> {existingClaim.reason}
        </p>
        <p>
          <strong>Claim Percentage:</strong> {existingClaim.claimPercentage}%,{" "}
          <strong>Supporting Document:</strong> {existingClaim.supportngDocs}
        </p>
        <Box component="form" sx={{ m: 3 }}>
          <Grid container spacing={2}>
            <TextField
            autoFocus
              label="Update Description"
              value={updateDescription}
              onChange={(e) => setUpdateDescription(e.target.value)}
              required
              fullWidth
              multiline
              rows={4}
            />
          </Grid>

          <Stack
            spacing={2}
            direction="row"
            justifyContent="center"
            alignItems="center"
            sx={{ mt: 2, mb: 2 }}
          >
            <Button
              variant="outlined"
              startIcon={<VerifiedUserOutlinedIcon />}
              color="primary"
              onClick={() => handleApproveClaim(existingClaim, updateDescription)}
            >
              Approve
            </Button>

            <Button
              variant="outlined"
              startIcon={<ThumbDownAltOutlinedIcon />}
              color="error"
              onClick={() => handleRejectClaim(existingClaim, updateDescription)}
            >
              Reject
            </Button>

            {/* <Button
              type="reset"
              variant="outlined"
              color="error"
            >
              Reset
            </Button>
            <Button type="submit" variant="outlined" color="primary">
              Add Update
            </Button> */}
          </Stack>
        </Box>
        {/* </form> */}
        {/* Display the history of updates on the claim */}
        {/* You can map through the data and display each update here */}
        {/* </div> */}
      </Box>
    </Container>
  );
};

export default ClaimView;
