import React, { useEffect, useState } from "react";
import {
  Button,
  Stack,
  Table,
  Container,
  Typography,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Paper,
} from "@mui/material";
import VerifiedUserOutlinedIcon from "@mui/icons-material/VerifiedUserOutlined";
import ThumbDownAltOutlinedIcon from "@mui/icons-material/ThumbDownAltOutlined";
import axios from "axios";

const ClientFormsApproveCancel = () => {
  const [pendingRegistrations, setPendingRegistrations] = useState([]);
  const [clientDetails, setClientDetails] = useState({});
  const status = "pending";

  useEffect(() => {
    axios
      .get(`http://localhost:9093/registerationDetail/${status}`)
      .then((response) => {
        setPendingRegistrations(response.data);
        console.log(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  useEffect(() => {
    // Fetch the client details based on the email
    const registrationEmails = pendingRegistrations.map(
      (registration) => registration.email
    );

    // Fetch client details for each email
    Promise.all(
      registrationEmails.map((email) =>
        axios.get(`http://localhost:9093/clientDetail/${email}`)
      )
    )
      .then((responses) => {
        const clientDetailsMap = {};
        responses.forEach((response, index) => {
          const clientData = response.data;
          clientDetailsMap[registrationEmails[index]] = clientData;
        });
        setClientDetails(clientDetailsMap);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [pendingRegistrations]);

  const updateReg = (data) => {
    return axios.put("http://localhost:9093/updateRegistration", data, {
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
      }
    })
      .then((response) => response.data)
  }

  const handleApproveRegistration = (registration) => {
    const data = {
      id: registration.id,
      email: registration.email,
      schemeName: registration.schemeName,
      registrationDate: registration.registrationDate,
      status: "approved",
    };

    updateReg(data).then((resp) => {
      window.location.reload();
      console.log(resp);
    }).catch((error) => {
      console.log(error);
    })

    // axios
    //   .put("http://localhost:9091/updateRegistration", data, {
    //     headers: {
    //       "Content-Type": "application/json",
    //       Accept: "application/json",
    //     },
    //   })
    //   .then((resp) => {
    //     window.location.reload();
    //     console.log(resp);
    //   })
    //   .catch((error) => {
    //     console.log(error);
    //   });
  };

  const handleCancelRegistration = (registration) => {
    const data = {
      id: registration.id,
      email: registration.email,
      schemeName: registration.schemeName,
      registrationDate: registration.registrationDate,
      status: "rejected",
    };

    updateReg(data).then((resp) => {
      window.location.reload();
      console.log(resp);
    }).catch((error) => {
      console.log(error);
    })

    // axios
    //   .put("http://localhost:9091/updateRegistration", data, {
    //     headers: {
    //       "Content-Type": "application/json",
    //       Accept: "application/json",
    //     },
    //   })
    //   .then((resp) => {
    //     window.location.reload();
    //     console.log(resp);
    //   })
    //   .catch((error) => {
    //     console.log(error);
    //   });
  };

  return (
    <Container component="main" maxWidth="md">
      <Typography component="h2" variant="h5" mt={6} mb={3} align="center">
        Client Forms Approve/Cancel
      </Typography>
      <Paper>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell sx={{ fontWeight: 'bold' }}>Client Name</TableCell>
              <TableCell sx={{ fontWeight: 'bold' }}>Scheme Name</TableCell>
              <TableCell sx={{ fontWeight: 'bold' }}>Registration Date</TableCell>
              <TableCell sx={{ fontWeight: 'bold' }} colSpan={2} align="center">
                Action
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {pendingRegistrations.map((registration) => (
              <TableRow key={registration.id}>
                <TableCell>
                  {clientDetails[registration.email]?.firstName}{" "}
                  {clientDetails[registration.email]?.lastName}
                </TableCell>
                <TableCell>{registration.schemeName}</TableCell>
                <TableCell>
                  {registration.registrationDate.split("T")[0]}
                </TableCell>
                <TableCell align="center">
                  <Button
                    variant="outlined"
                    startIcon={<VerifiedUserOutlinedIcon />}
                    color="primary"
                    onClick={() => handleApproveRegistration(registration)}
                  >
                    Approve
                  </Button>
                </TableCell>
                <TableCell align="center">
                  <Button
                    variant="outlined"
                    startIcon={<ThumbDownAltOutlinedIcon />}
                    color="error"
                    onClick={() => handleCancelRegistration(registration)}
                  >
                    Reject
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
    </Container>
  );
};

export default ClientFormsApproveCancel;

// import React, { useEffect, useState } from "react";
// import {
//   Button,
//   Stack,
//   Table,
//   Container,
//   Typography,
//   TableBody,
//   TableCell,
//   TableHead,
//   TableRow,
//   Paper,
// } from "@mui/material";
// import VerifiedUserOutlinedIcon from "@mui/icons-material/VerifiedUserOutlined";
// import ThumbDownAltOutlinedIcon from "@mui/icons-material/ThumbDownAltOutlined";
// import axios from "axios";

// const ClientFormsApproveCancel = () => {
//   // Sample data to demonstrate pending client registrations
//   const [pendingRegistrations, setPendingRegistrations] = useState([]);
//   const [data, setData] = useState([]);
//   const [email, setEmail] = useState('');

//   const status = "pending";

//   useEffect(() => {
//     // Make an API call to retrieve the scheme details based on the schemeName
//     axios
//       .get(`http://localhost:9093/registerationDetail/${status}`)
//       .then((response) => {
//         console.log(response);
//         console.log(response.data);

//         setPendingRegistrations(response.data);
//       })
//       .catch((error) => {
//         console.log(error);
//       });
//   }, []);

//   const clientDetails = (email) => {
//     return axios
//       .get(`http://localhost:9093/clientDetail/${email}`)
//       .then((response) => response.data);
//   };

//   useEffect(() => {
//     clientDetails(email)
//       .then((resp) => {
//         const fData = {
//           firstName: resp.firstName,
//           lastName: resp.lastName,
//           address: resp.address,
//           phoneNo: resp.phoneNo,
//           pincode: resp.pincode,
//           pancardNo: resp.pancardNo,
//           aadharNo: resp.aadharNo,
//         };
//         setData(fData);
//         console.log(resp);
//         console.log(data);
//       })
//       .catch((error) => {
//         console.log(error);
//       });
//   }, []);

//   const handleApproveRegistration = (registration) => {
//     const data = {
//       id : registration.id,
//       email: registration.email,
//       schemeName: registration.schemeName,
//       registrationDate: registration.registrationDate,
//       status: "approved",
//     };
//     axios
//       .put("http://localhost:9093/updateRegistration", data, {
//         headers: {
//           "Content-Type": "application/json",
//           Accept: "application/json",
//         },
//       })
//       .then((resp) => {
//         window.location.reload();
//         console.log(resp);
//       })
//       .catch((error) => {
//         console.log(error);
//       });
//   };

//   // Handler for approving a client registration
//   // const handleApproveRegistration = async () => {
//   //   const data = {
//   //     email : pendingRegistrations.email,
//   //     schemeName : pendingRegistrations.schemeName,
//   //     registrationDate : pendingRegistrations.registrationDate,
//   //     status : "Approved"
//   //   }
//   //   try {
//   //     const response = await axios.put(`http://localhost:9093/updateRegistration`, data);
//   //     if (response.status === 200) {
//   //       // Update the UI or handle success
//   //       window.location.reload();
//   //       console.log('Approved');
//   //     } else {
//   //       console.error('Failed to approve');
//   //     }
//   //   } catch (error) {
//   //     console.log(error);
//   //   }
//   // };

//   // Handler for canceling a client registration
//   const handleCancelRegistration = (registration) => {
//     const data = {
//       id : registration.id,
//       email: registration.email,
//       schemeName: registration.schemeName,
//       registrationDate: registration.registrationDate,
//       status: "rejected",
//     };
//     axios
//       .put("http://localhost:9093/updateRegistration", data, {
//         headers: {
//           "Content-Type": "application/json",
//           Accept: "application/json",
//         },
//       })
//       .then((resp) => {
//         window.location.reload();
//         console.log(resp);
//       })
//       .catch((error) => {
//         console.log(error);
//       });
//   };

//   return (
//     <Container component="main" maxWidth="md">
//       {/* <div> */}
//       <Typography component="h2" variant="h5" mt={6} mb={3} align="center">
//         Client Forms Approve/Cancel
//       </Typography>
//       {/* <h2>Client Forms Approve/Cancel</h2> */}
//       <Paper>
//         <Table>
//           <TableHead>
//             <TableRow>
//               <TableCell>Client Name</TableCell>
//               <TableCell>Policy Type</TableCell>
//               <TableCell>Registration Date</TableCell>
//               <TableCell colSpan={2} align="center">
//                 Action
//               </TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {pendingRegistrations.map((registration) => (
//               <TableRow key={registration.id}>
//                 {setEmail(registration.email)}
//                 <TableCell>{data.firstName}</TableCell>
//                 <TableCell>{registration.schemeName}</TableCell>
//                 <TableCell>
//                   {registration.registrationDate.split("T")[0]}
//                 </TableCell>
//                 <TableCell align="center">
//                   {/* <Stack spacing={2} direction="row" justifyContent='center' alignItems='center'> */}
//                   <Button
//                     variant="outlined"
//                     startIcon={<VerifiedUserOutlinedIcon />}
//                     color="primary"
//                     onClick={() => handleApproveRegistration(registration)}
//                   >
//                     Approve
//                   </Button>
//                 </TableCell>
//                 <TableCell align="center">
//                   <Button
//                     variant="outlined"
//                     startIcon={<ThumbDownAltOutlinedIcon />}
//                     color="error"
//                     onClick={() => handleCancelRegistration(registration)}
//                   >
//                     Reject
//                   </Button>
//                   {/* </Stack> */}
//                 </TableCell>
//               </TableRow>
//             ))}
//           </TableBody>
//         </Table>
//       </Paper>
//       {/* </div> */}
//     </Container>
//   );
// };

// export default ClientFormsApproveCancel;
