import React, { useState } from 'react';
import SendIcon from '@mui/icons-material/Send';

import {
  Container,
  Typography,
  Paper,
  List,
  ListItem,
  ListItemText,
  Divider,
  TextField,
  Button,
} from '@mui/material';

const AdminQueryPage = () => {
  // Sample data for client queries
  const initialClientQueries = [
    {
      id: 1,
      name: 'John Doe',
      email: 'john.doe@example.com',
      query: 'I have a question about my insurance claim status.',
      date: '2023-08-02',
      reply: '',
    },
    {
      id: 2,
      name: 'Jane Smith',
      email: 'jane.smith@example.com',
      query: 'How can I update my contact information?',
      date: '2023-08-01',
      reply: '',
    },
  ];

  const [clientQueries, setClientQueries] = useState(initialClientQueries);

  // Function to handle admin reply to client query
  const handleReply = (id, reply) => {
    const updatedClientQueries = clientQueries.map((query) =>
      query.id === id ? { ...query, reply } : query
    );
    setClientQueries(updatedClientQueries);
  };

  return (
    <Container component="main" maxWidth="md">
      <Typography component="h1" variant="h5" mt={6} mb={3} align="center">
        Client Queries
      </Typography>

      <Paper elevation={3}>
        <List>
          {clientQueries.map((query) => (
            <React.Fragment key={query.id}>
              <ListItem>
                <ListItemText
                  primary={query.name}
                  secondary={
                    <>
                      <Typography component="span" variant="body2" color="text.primary">
                        {query.email}
                      </Typography>
                      <br />
                      {query.query}
                      <br />
                      <Typography component="span" variant="body2" color="text.secondary">
                        {query.date}
                      </Typography>
                    </>
                  }
                />
              </ListItem>
              <Divider component="li" />
              <ListItem>
                <TextField
                  fullWidth
                  label="Admin Reply"
                  variant="outlined"
                  value={query.reply}
                  onChange={(e) => handleReply(query.id, e.target.value)}
                />
                <Button
                  variant="outlined"
                  endIcon={<SendIcon />}
                  color="primary"
                  onClick={() => handleReply(query.id, query.reply)}
                  style={{ marginLeft: '8px' }}
                >
                  Send
                </Button>
              </ListItem>
            </React.Fragment>
          ))}
        </List>
      </Paper>
    </Container>
  );
};

export default AdminQueryPage;
